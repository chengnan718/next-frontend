// ** MUI Imports
import { Stack } from '@mui/material'
import Box from '@mui/material/Box'
import Link from '@mui/material/Link'
import Typography from '@mui/material/Typography'
import TelegramIcon from '@mui/icons-material/Telegram'
import XIcon from '@mui/icons-material/X'

const FooterContent = () => {
  return (
    <Box
      sx={{
        display: 'flex',
        flexWrap: 'wrap',
        alignItems: 'center',
        justifyContent: 'center',
        '@media (max-width: 600px)': {
          flexDirection: 'column',
          alignItems: 'flex-start'
        }
      }}
    >
      <Stack direction={{ xs: 'row', sm: 'row' }} spacing={2} alignItems='center'>
        <Typography sx={{ mr: 2, marginBottom: '9px !important', letterSpacing: '-0.07em', fontSize: 19 }}>
          <span>{`©`}</span>
          <span
            style={{ letterSpacing: '-0.01em', marginLeft: '0px', marginRight: '3px' }}
          >{` ${new Date().getFullYear()}`}</span>
          <span style={{ letterSpacing: '-0.02em', marginLeft: 5 }}>Send Me A Note</span>
        </Typography>
      </Stack>
      <Stack direction={'row'} spacing={2} sx={{ marginLeft: 50 }}>
        <Link href='https://t.me/sendmeanote'>
          <TelegramIcon sx={{ width: '30px', height: '30px', marginLeft: 2, marginTop: -1 }} />
        </Link>
        <Link href='https://x.com/sendmeanote'>
          <XIcon style={{ width: '23px', height: '23px', marginTop: '0px' }} />
        </Link>
      </Stack>
    </Box>
  )
}

export default FooterContent
