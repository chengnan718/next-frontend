export const parse_fetch_response = async (response: any) => {
  if (response.ok) {
    return response.json()
  }
  let errorText = 'Something went wrong'
  try {
    errorText = await response.text()
  } catch (e) {}
  throw new Error(`Error code: ${response.status} : ${errorText}`)
}

export const jsonSafeParse = (str: string, defaultValue = null) => {
  try {
    return JSON.parse(str)
  } catch (error) {
    console.error('Error parsing JSON:', error)

    return defaultValue
  }
}

export const dd = function (number: number): string {
  return number > 9 ? '' + number : '0' + number
}

// This function is deprecated.
// Instead, use dayjs
// dayjs(new Date()).format("YYYY-MM-DD")
// npm i dayjs
export const date2str = function (this_date: Date, style: number = 0): string {
  if (!this_date) return ''

  // As default, mysql date format
  let datetime: string =
    this_date.getFullYear() +
    '-' +
    dd(this_date.getMonth() + 1) +
    '-' +
    dd(this_date.getDate()) +
    ' ' +
    dd(this_date.getHours()) +
    ':' +
    dd(this_date.getMinutes()) +
    ':' +
    dd(this_date.getSeconds())
  if (style === 1) {
    datetime =
      this_date.getFullYear() +
      '/' +
      dd(this_date.getMonth() + 1) +
      '/' +
      dd(this_date.getDate()) +
      ' ' +
      dd(this_date.getHours()) +
      ':' +
      dd(this_date.getMinutes()) +
      ':' +
      dd(this_date.getSeconds())
  }

  return datetime
}

export const getCurrentUrl = (): string => {
  let currentUrl = window.location.href

  // Check if the last character is '/' and remove it
  if (currentUrl.endsWith('/')) {
    currentUrl = currentUrl.slice(0, -1)
  }

  return currentUrl
}

export const id2item = (id: ID, list: Array<any>): any => {
  if (!list) return null
  for (let i = 0; i < list.length; i++) {
    if (list[i]['id'] == id) {
      return list[i]
    }
  }

  return null
}

export const push_non_duplicate = (value: any, list: Array<any>): void => {
  if (!value) {
    return
  }
  for (let i = 0; i < list.length; i++) {
    if (list[i] === value) {
      return
    }
  }
  list.push(value)
}

export const push_non_duplicate_id = (value: any, list: Array<any>): void => {
  if (!value?.id) {
    return
  }
  for (let i = 0; i < list.length; i++) {
    if (list[i]?.id === value.id) {
      return
    }
  }
  list.push(value)
}

export const capitalizeFirstLetterOfEachWord = (string: string): string => {
  if (!string) return ''

  return string
    .split(' ')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ')
}

export const jobIdToBigInt = (jobId: string): bigint => {
  // jobId is `${timestamp}${uuid_with_no_hyphens}`
  return BigInt(`0x${jobId}`)
}

export const bigIntToJobId = (bigIntValue: bigint): string => {
  // Convert the BigInt to a hexadecimal string and remove the "0x" prefix
  let hexString = bigIntValue.toString(16)
  hexString = hexString.replace(/0x/g, '')
  hexString = hexString.toLowerCase()

  return `${hexString}`
}

export const checkIfExpired = (created_at: any): boolean => {
  const created_at_date = new Date(created_at)
  const now = new Date()
  const twentyFourHoursAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000)

  return created_at_date < twentyFourHoursAgo
}

export const formatDate = (dateString: any) => {
  const date = new Date(dateString)

  const year = date.getFullYear() // Four-digit year
  const month = String(date.getMonth() + 1).padStart(1, '0') // Month without leading zero
  const day = String(date.getDate()).padStart(1, '0') // Day with leading zero
  const hours = String(date.getHours()).padStart(2, '0')
  const minutes = String(date.getMinutes()).padStart(2, '0')
  const seconds = String(date.getSeconds()).padStart(2, '0')

  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`
}
