export enum PayStatus {
  None = 0,
  Offer = 1,
  Refunded = 2,
  Completed = 3,
}

export const payStatusText = [
  "None", "Offer", "Refunded", "Completed",
];