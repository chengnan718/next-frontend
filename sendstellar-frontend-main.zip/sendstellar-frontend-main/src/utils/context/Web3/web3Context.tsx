// context/Web3Modal.tsx
'use client'

import { createContext, useContext } from 'react'
import { showSnackBar } from 'src/store/slices/snackbar.slice'
import { useAppDispatch } from 'src/store/hooks'
import { isConnected, requestAccess, signTransaction } from '@stellar/freighter-api'

import * as StellarSDK from 'stellar-sdk'

const server = new StellarSDK.Horizon.Server('https://horizon-testnet.stellar.org')

const Web3Context = createContext<any>(null)

// Set the time condition to 1 day (24 hours)
const currentTime = new Date()
const claimBeforeTime = Math.floor(currentTime.getTime() / 1000) + 72 * 60 * 60 // 3 days in seconds

export const Web3Provider = ({ children }: any) => {
  const dispatch = useAppDispatch()

  // Function to get the status of installed wallet
  const connectState = async () => {
    const isAppConnected = await isConnected()

    if (isAppConnected.isConnected) {
      return true
    } else {
      return false
    }
  }

  // Function to get the public key - wallet address
  const retrievePublicKey = async () => {
    const accessObj = await requestAccess()

    if (accessObj.error) {
      dispatch(showSnackBar({ type: 'error', message: accessObj.error.message }))
      console.log('Retrieve Account Error', accessObj.error)
    } else {
      return accessObj.address
    }
  }

  // Function to the sign every transaction with Freighter wallet
  const userSignTransaction = async (xdr: string, networkPassphrase: string, signWith: string) => {
    // This step triggers Freighter to sign the transaction
    const signedTransactionRes = await signTransaction(xdr, {
      networkPassphrase, // e.g., 'Test SDF Network ; September 2015' for the TESTNET
      address: signWith
    })

    // If the user rejects signing, an error is returned
    if (signedTransactionRes.error) {
      dispatch(showSnackBar({ type: 'error', message: signedTransactionRes.error.message }))
      console.log('Signed Error', signedTransactionRes.error.message)
    } else {
      // If the user approves signing, you get the signed XDR
      return signedTransactionRes.signedTxXdr
    }
  }

  // Funtion to send XLM token from one to another wallet address
  const sendXLM = async (sender: string, receiver: string, amount: string) => {
    const account = await server.loadAccount(sender)
    const fee = (await server.fetchBaseFee()).toString()
    const transaction = new StellarSDK.TransactionBuilder(account, {
      fee,
      networkPassphrase: StellarSDK.Networks.TESTNET,
      timebounds: await server.fetchTimebounds(180)
    })
      .addOperation(
        StellarSDK.Operation.payment({
          destination: receiver,
          asset: StellarSDK.Asset.native(),
          amount: amount
        })
      )
      .build()

    const XDR = transaction.toXDR()

    const userSignedTransaction = await userSignTransaction(XDR, StellarSDK.Networks.TESTNET, sender)

    if (userSignedTransaction) {
      const transactionToSubmit = StellarSDK.TransactionBuilder.fromXDR(
        userSignedTransaction,
        StellarSDK.Networks.TESTNET
      )

      try {
        const result = await server.submitTransaction(transactionToSubmit)

        return result
      } catch (e: any) {
        console.log('Error send submit', e.response.data)
      }
    } else {
      console.log('No signed transaction returned')
    }
  }

  // this function calls when the supporter send XLM and note to the creator
  const sendXLMClaimableCondition = async (supporter: string, creator: string, amount: string) => {
    try {
      // Check the wallet connection status
      if (!(await isConnected())) {
        dispatch(showSnackBar({ type: 'error', message: 'Connect the Freighter Wallet' }))

        return
      }

      const supporterAccount = await server.loadAccount(supporter)
      const fee = (await server.fetchBaseFee()).toString()

      // Create a transaction with a claimable balance operation
      const transaction = new StellarSDK.TransactionBuilder(supporterAccount, {
        fee: fee,
        networkPassphrase: StellarSDK.Networks.TESTNET
      })
        .addOperation(
          StellarSDK.Operation.createClaimableBalance({
            asset: StellarSDK.Asset.native(),
            amount: amount,
            claimants: [
              new StellarSDK.Claimant(creator, StellarSDK.Claimant.predicateUnconditional()), // Claimant 1: the creator get paid XLM when they reply
              new StellarSDK.Claimant(
                supporter,
                StellarSDK.Claimant.predicateBeforeAbsoluteTime(claimBeforeTime.toString()) // Claimant 2: the supporter can reclaim without reply for 3 days
              )
            ]
          })
        )
        .setTimeout(180)
        .build()

      // Use Freighter wallet to sign the transaction
      const userSignedTransaction = await userSignTransaction(
        transaction.toXDR(),
        StellarSDK.Networks.TESTNET,
        supporter
      )

      if (userSignedTransaction) {
        const transactionToSubmit = StellarSDK.TransactionBuilder.fromXDR(
          userSignedTransaction,
          StellarSDK.Networks.TESTNET
        )

        try {
          // Submit the signed transaction to the network
          const result = await server.submitTransaction(transactionToSubmit)
          console.log('Result', result)

          // Get the balance Id
          const balances = await server
            .claimableBalances()
            .claimant(creator)
            .limit(1)
            .order('desc')
            .call()
            .catch(function (err) {
              console.error(`Claimable balance retrieval failed: ${err}`)
            })
          if (!balances) {
            return
          }
          const balanceId = balances.records[0].id
          console.log('Balance ID (3):', balanceId)

          return balanceId
        } catch (e: any) {
          console.log('Error send submit', e.response.data)
        }
      } else {
        console.log('No signed transaction returned')
      }
    } catch (err) {
      console.error('Error sending XLM with Claimable Condition:', err)
    }
  }

  // this function calls when the supporter reclaim the balance after 3 days if the creator doesn't reply
  const reclaimBalance = async (supporter: string, balanceId: string) => {
    try {
      const supporterAccount = await server.loadAccount(supporter)
      const fee = (await server.fetchBaseFee()).toString()

      // Create a transaction to reclaim the balance
      const transaction = new StellarSDK.TransactionBuilder(supporterAccount, {
        fee: fee,
        networkPassphrase: StellarSDK.Networks.TESTNET
      })
        .addOperation(
          StellarSDK.Operation.claimClaimableBalance({
            balanceId: balanceId
          })
        )
        .setTimeout(180)
        .build()

      // Use Freighter wallet to sign the transaction
      const userSignedTransaction = await userSignTransaction(
        transaction.toXDR(),
        StellarSDK.Networks.TESTNET,
        supporter
      )

      if (userSignedTransaction) {
        const transactionToSubmit = StellarSDK.TransactionBuilder.fromXDR(
          userSignedTransaction,
          StellarSDK.Networks.TESTNET
        )

        try {
          // Submit the signed transaction to the network
          const result = await server.submitTransaction(transactionToSubmit)

          // Save transaction details and note to the backend
          return result
        } catch (e: any) {
          console.log('Error send submit', e.response.data)
        }
      } else {
        console.log('No signed transaction returned')
      }
    } catch (err) {
      console.error('Error reclaiming balance:', err)
    }
  }

  // this function calls when the creator reply to their note from the supporter
  const claimBlance = async (creator: string, balanceId: string) => {
    try {
      const creatorAccount = await server.loadAccount(creator)
      const fee = (await server.fetchBaseFee()).toString()

      // Create a transaction to claim the balance
      const transaction = new StellarSDK.TransactionBuilder(creatorAccount, {
        fee: fee,
        networkPassphrase: StellarSDK.Networks.TESTNET
      })
        .addOperation(
          StellarSDK.Operation.claimClaimableBalance({
            balanceId: balanceId
          })
        )
        .setTimeout(180)
        .build()

      console.log('T', transaction.toXDR())

      // Use Freighter wallet to sign the transaction
      const userSignedTransaction = await userSignTransaction(transaction.toXDR(), StellarSDK.Networks.TESTNET, creator)

      console.log('S', userSignTransaction)

      if (userSignedTransaction) {
        const transactionToSubmit = StellarSDK.TransactionBuilder.fromXDR(
          userSignedTransaction,
          StellarSDK.Networks.TESTNET
        )

        try {
          // Submit the signed transaction to the network
          const result = await server.submitTransaction(transactionToSubmit)

          // Save transaction details and note to the backend
          return result
        } catch (e: any) {
          console.log('Error send submit', e.response.data)
        }
      } else {
        console.log('No signed transaction returned')
      }
    } catch (err) {
      console.error('Error claiming balance:', err)
    }
  }

  return (
    <Web3Context.Provider
      value={{ connectState, retrievePublicKey, sendXLM, sendXLMClaimableCondition, reclaimBalance, claimBlance }}
    >
      {children}
    </Web3Context.Provider>
  )
}

export const useWeb3 = () => useContext(Web3Context)
