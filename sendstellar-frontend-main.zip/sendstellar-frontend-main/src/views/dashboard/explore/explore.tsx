import { Paper, Box, Stack, Typography, Avatar } from '@mui/material'
import { useState, useEffect, useMemo, useCallback } from 'react'
import { MaterialReactTable, type MRT_ColumnDef } from 'material-react-table'
import { useAppSelector, useAppDispatch } from 'src/store/hooks'
import { MainSliceState } from 'src/store/slices/main.slice'
import StyledBadge from 'src/views/custom/StyledBadge'
import { showSnackBar } from 'src/store/slices/snackbar.slice'

const API_URL = process.env.NEXT_PUBLIC_API_URL

const CarouselItem = ({ item, onClick }: { item: any; onClick: () => void }) => (
  <Stack
    direction='row'
    alignItems={'center'}
    spacing={1}
    sx={{
      py: 7,
      transition: 'transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out, background-color 0.3s ease-in-out',
      borderRadius: 2,
      '&:hover': {
        cursor: 'pointer',
        transform: 'scale(1.05)'
      }
    }}
    onClick={onClick}
  >
    <StyledBadge
      variant='standard'
      overlap='circular'
      badgeContent=' '
      anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
    >
      <Avatar alt={`${item.fullname}`} src={'/images/avatars/1.png'} sx={{ width: 96, height: 96, ml: 10 }} />
    </StyledBadge>
    <Box sx={{ marginLeft: '0 !important' }}>
      <Typography variant='body1'>{item.fullname}</Typography>
      <Stack direction='row' alignItems={'center'} spacing={2}>
        <Typography variant='caption'>{item.head.length > 25 ? item.head.slice(0, 25) + '...' : item.head}</Typography>
      </Stack>
    </Box>
  </Stack>
)

const CustomCarousel = ({ items }: { items: Array<any> }) => {
  const [currentIndex, setCurrentIndex] = useState(0)
  const itemsPerPage = 1

  const handleIndicatorClick = (index: number) => {
    setCurrentIndex(index * itemsPerPage)
  }

  const handleItemClick = (item: any) => {
    const pageLink = `/c/${item.pagename}`
    window.open(pageLink, '_blank', 'noopener,noreferrer')
  }

  return (
    <Box sx={{ position: 'relative', overflow: 'hidden' }}>
      <Box sx={{ display: 'flex', transition: 'transform 0.5s', transform: `translateX(-${currentIndex}px)` }}>
        {items.map((item, index) => (
          <CarouselItem key={index} item={item} onClick={() => handleItemClick(item)} />
        ))}
      </Box>
      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2 }}>
        {items.map((_, index) => (
          <Box
            key={index}
            sx={{
              width: 8,
              height: 8,
              borderRadius: '50%',
              backgroundColor: index === currentIndex / itemsPerPage ? 'primary.main' : 'grey.500',
              mx: 1,
              mt: -2,
              cursor: 'pointer'
            }}
            onClick={() => handleIndicatorClick(index)}
          />
        ))}
      </Box>
    </Box>
  )
}

const CreatorExploreComponent = () => {
  const { onlineStatus } = useAppSelector<MainSliceState>(state => state.main)
  const dispatch = useAppDispatch()

  // ** States
  const [list, setList] = useState<Array<any>>([])

  const load_data = useCallback(() => {
    fetch(API_URL + '/creators/all')
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          console.log('RRR', data.results)
          setList(data.results)
        } else {
          setList([])
        }
      })
      .catch(error => {
        console.log(error)
        dispatch(showSnackBar({ type: 'error', message: `Error on AJAX call: ${error.toString()}` }))
      })
  }, [dispatch]) // Dependency array for load_data, add dependencies like 'dispatch'

  useEffect(() => {
    load_data()
  }, [load_data]) // Include load_data as a dependency

  const columns = useMemo<MRT_ColumnDef<any>[]>(
    () => [
      {
        accessorKey: 'fullname',
        header: 'Name',
        Cell: ({ cell }: any) => {
          const row = cell.row.original

          return (
            <Stack direction='row' alignItems={'center'} spacing={4}>
              <StyledBadge
                color={onlineStatus?.[row.expert_id] ? 'success' : 'secondary'}
                variant='standard'
                overlap='circular'
                badgeContent=' '
                anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
              >
                <Avatar
                  alt={`${row.expert_first_name} ${row.expert_last_name}`}
                  src={'/images/avatars/1.png'}
                  sx={{ width: 48, height: 48 }}
                />
              </StyledBadge>
              <Box>
                <Typography variant='body1'>{`${row.fullname}`}</Typography>
                <Stack direction='row' alignItems={'center'} spacing={2}>
                  <Typography variant='caption'>{`sendmeanote.app/c/${row.pagename}`}</Typography>
                </Stack>
              </Box>
            </Stack>
          )
        }
      },
      {
        accessorKey: 'head',
        header: 'Introduction'
      },
      {
        accessorKey: 'note_acount',
        header: 'Notes'
      }
    ],
    [onlineStatus]
  )

  // ** Row click handler
  const handleRowClick = (row: any) => {
    const pageLink = `/c/${row.original.pagename}`
    window.open(pageLink, '_blank', 'noopener,noreferrer')
  }

  return (
    <Paper sx={{ width: '100%', overflow: 'hidden' }}>
      <Typography variant='h4' sx={{ textAlign: 'center', mt: 10, textShadow: '2px 2px 4px rgba(0, 0, 0, 0.3)' }}>
        Top Rating Creators
      </Typography>

      <CustomCarousel items={list} />

      <Box sx={{ mt: 5 }}>
        <MaterialReactTable
          columns={columns}
          data={list}
          enablePagination
          enableSorting
          enableColumnResizing
          layoutMode='grid'
          initialState={{
            pagination: { pageSize: 5, pageIndex: 0 },
            sorting: [{ id: 'created_at', desc: true }]
          }}
          muiTableBodyRowProps={({ row }) => ({
            hover: true,
            onClick: () => handleRowClick(row), // Add the click handler
            sx: { cursor: 'pointer' } // Add pointer cursor on row hover
          })}
          muiTableProps={{
            sx: {
              '& .MuiTableCell-root': {
                py: 2
              }
            }
          }}
        />
      </Box>
    </Paper>
  )
}

export default CreatorExploreComponent
