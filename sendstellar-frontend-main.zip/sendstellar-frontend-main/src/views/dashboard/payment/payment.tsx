import { Card, CardContent, Box, Button, Typography, Grid, Container, Divider } from '@mui/material'
import React, { useState, useCallback, useEffect } from 'react'
import { useAppDispatch } from 'src/store/hooks'
import List from '@mui/material/List'
import ListItem from '@mui/material/ListItem'
import ListItemAvatar from '@mui/material/ListItemAvatar'
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft'
import ChevronRightIcon from '@mui/icons-material/ChevronRight'
import { showSnackBar } from 'src/store/slices/snackbar.slice'
import { formatDate } from 'src/utils/custom'

const API_URL = process.env.NEXT_PUBLIC_API_URL

const lists: any = [
  { type: 'USD', amount: '10', date: '2024-9-20 3:20:12' },
  { type: 'USD', amount: '20', date: '2024-9-20 3:25:22' }
]

const PaymentComponent = () => {
  const [currentPage, setCurrentPage] = useState(1)
  const [currentMPage, setCurrentMPage] = useState(1)
  const dispatch = useAppDispatch()

  // ** States
  const [items, setItems] = useState<Array<any>>([])

  // Set the Paginated Items
  const itemsPerPage = 5
  const handleNextPage = () => {
    setCurrentPage(prev => Math.min(prev + 1, Math.ceil(items.length / itemsPerPage)))
  }
  const handlePrevPage = () => {
    setCurrentPage(prev => Math.max(prev - 1, 1))
  }
  const startIndex = (currentPage - 1) * itemsPerPage
  const paginatedItems = items.slice(startIndex, startIndex + itemsPerPage)

  // Set the Moneygram paginated items
  const itemsMPerPage = 5
  const handleNextMPage = () => {
    setCurrentMPage(prev => Math.min(prev + 1, Math.ceil(lists.length / itemsMPerPage)))
  }
  const handlePrevMPage = () => {
    setCurrentMPage(prev => Math.max(prev - 1, 1))
  }
  const startMIndex = (currentMPage - 1) * itemsMPerPage
  const paginatedLists = lists.slice(startMIndex, startMIndex + itemsMPerPage)

  // Load the initial data
  const load_data = useCallback(() => {
    fetch(API_URL + '/notes')
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          setItems(data.results)
        } else {
          setItems([])
        }
      })
      .catch(error => {
        console.log(error)
        dispatch(showSnackBar({ type: 'error', message: `Error on AJAX call: ${error.toString()}` }))
      })
  }, [dispatch]) // Dependency array for load_data, add dependencies like 'dispatch'

  useEffect(() => {
    load_data()
  }, [load_data]) // Include load_data as a dependency

  return (
    <Box sx={{ mr: -3 }}>
      <Container>
        <Grid container spacing={5} sx={{ mt: -5 }}>
          <Grid item xs={12} md={6}>
            <Card
              sx={{
                background: 'linear-gradient(to bottom, #FFFFFF, #f2f6f8)', // Sky-like gradient
                borderRadius: 2,
                pb: 2
              }}
            >
              <CardContent className='flex flex-col gap-2 relative items-start'>
                <Box sx={{ pt: 1 }}>
                  <Typography
                    variant='h4'
                    sx={{ textAlign: 'center', pb: 5, mt: 3, textShadow: '2px 2px 4px rgba(0, 0, 0, 0.3)' }}
                  >
                    Stellar PayIn
                  </Typography>
                </Box>
                <Box sx={{ pl: 4, pr: 4, pt: 7, pb: 7 }}>
                  <Grid container spacing={2}>
                    <Grid item xs={12} md={6}>
                      <Typography variant='h6' color='textSecondary'>
                        Total
                      </Typography>
                      <Box sx={{ position: 'relative', display: 'inline-block', mt: 2, mb: 1 }}>
                        <Typography variant='h5' color='primary'>
                          1500 XLM
                        </Typography>
                      </Box>
                      <Typography variant='h6' color='primary' sx={{ ml: 1 }}>
                        ($160)
                      </Typography>
                    </Grid>
                    <Grid item xs={12} md={6} sx={{ textAlign: 'right' }}>
                      <Typography variant='h6' color='textSecondary'>
                        Balance
                      </Typography>
                      <Box sx={{ position: 'relative', display: 'inline-block', mt: 2, mb: 1 }}>
                        <Typography variant='h5' color='primary'>
                          970 XLM
                        </Typography>
                      </Box>
                      <Typography variant='h6' color='primary' sx={{ mr: 1 }}>
                        ($92.69)
                      </Typography>
                    </Grid>
                  </Grid>
                </Box>

                <Divider />

                <Grid container>
                  <Grid item xs={12} md={12}>
                    {/* Conditionally render list or "No items found" */}
                    {paginatedItems.length > 0 ? (
                      <List>
                        {paginatedItems.map((item: any, index: any) => (
                          <ListItem
                            key={index}
                            sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}
                          >
                            <Box sx={{ display: 'flex', alignItems: 'center', p: 1 }}>
                              <ListItemAvatar>
                                <img
                                  src='/images/logos/stellar.png'
                                  alt='stellar xlm'
                                  style={{ width: '40px', height: '40px', objectFit: 'contain' }}
                                />
                              </ListItemAvatar>
                              <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                                <Typography variant='body1'>{item.fullname}</Typography>
                                <Typography variant='body2'>{item.xlm_amount} XLM</Typography>
                              </Box>
                            </Box>
                            {/* Date aligned to the right */}
                            <Typography variant='body2' sx={{ alignSelf: 'center' }}>
                              {formatDate(item.created_at)}
                            </Typography>
                          </ListItem>
                        ))}
                      </List>
                    ) : (
                      <Box sx={{ textAlign: 'center', mt: 4, mb: 3 }}>
                        <Typography variant='body1' color='textSecondary'>
                          No History found
                        </Typography>
                      </Box>
                    )}

                    {/* Pagination Controls */}
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 2 }}>
                      {/* Total Items and Current Page Info */}
                      <Typography variant='body2' sx={{ ml: 7 }}>
                        {`Page ${currentPage} of ${Math.ceil(items.length / itemsPerPage)} (${items.length} items)`}
                      </Typography>

                      {/* Pagination Buttons Aligned to the Right */}
                      <Box sx={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center', mr: 3 }}>
                        <Button
                          variant='contained'
                          onClick={handlePrevPage}
                          disabled={currentPage === 1}
                          sx={{ mr: 2 }}
                        >
                          <ChevronLeftIcon />
                        </Button>
                        <Button
                          variant='contained'
                          onClick={handleNextPage}
                          disabled={currentPage === Math.ceil(items.length / itemsPerPage)}
                        >
                          <ChevronRightIcon />
                        </Button>
                      </Box>
                    </Box>
                  </Grid>
                </Grid>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} md={6}>
            <Card
              sx={{
                background: 'linear-gradient(to bottom, #FFFFFF, #f2f6f8)', // Sky-like gradient
                borderRadius: 2,
                pb: 2
              }}
            >
              <CardContent className='flex flex-col gap-2 relative items-start'>
                <Box sx={{ pt: 1 }}>
                  <Typography
                    variant='h4'
                    sx={{ textAlign: 'center', pb: 5, mt: 3, textShadow: '2px 2px 4px rgba(0, 0, 0, 0.3)' }}
                  >
                    MoneyGram PayOut
                  </Typography>
                </Box>
                <Box sx={{ pl: 4, pr: 4, pt: 7, pb: 5 }}>
                  <Grid container spacing={2}>
                    <Grid item xs={12} md={12}>
                      <Typography variant='h6' color='textSecondary'>
                        Total
                      </Typography>
                      <Box sx={{ position: 'relative', display: 'inline-block', mt: 2, mb: 1 }}>
                        <Typography variant='h5' color='primary'>
                          $50
                        </Typography>
                      </Box>
                    </Grid>
                  </Grid>
                  <Button size='small' variant='outlined' sx={{ mt: 2, marginBottom: '2px' }}>
                    Withdraw Now
                  </Button>
                </Box>

                <Divider />

                <Grid container>
                  <Grid item xs={12} md={12}>
                    {/* Conditionally render list or "No items found" */}
                    {paginatedLists.length > 0 ? (
                      <List>
                        {paginatedLists.map((item: any, index: any) => (
                          <ListItem
                            key={index}
                            sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}
                          >
                            <Box sx={{ display: 'flex', alignItems: 'center', p: 1 }}>
                              <ListItemAvatar>
                                <img
                                  src='/images/logos/usd.png'
                                  alt='stellar xlm'
                                  style={{ width: '40px', height: '40px', objectFit: 'contain' }}
                                />
                              </ListItemAvatar>
                              <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                                <Typography variant='body1'>{item.type}</Typography>
                                <Typography variant='body2'>{item.amount} XLM</Typography>
                              </Box>
                            </Box>
                            {/* Date aligned to the right */}
                            <Typography variant='body2' sx={{ alignSelf: 'center' }}>
                              {formatDate(item.date)}
                            </Typography>
                          </ListItem>
                        ))}
                      </List>
                    ) : (
                      <Box sx={{ textAlign: 'center', mt: 4, mb: 3 }}>
                        <Typography variant='body1' color='textSecondary'>
                          No History found
                        </Typography>
                      </Box>
                    )}

                    {/* Pagination Controls */}
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 2 }}>
                      {/* Total Items and Current Page Info */}
                      <Typography variant='body2' sx={{ ml: 7 }}>
                        {`Page ${currentMPage} of ${Math.ceil(lists.length / itemsMPerPage)} (${lists.length} items)`}
                      </Typography>

                      {/* Pagination Buttons Aligned to the Right */}
                      <Box sx={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center', mr: 3 }}>
                        <Button
                          variant='contained'
                          onClick={handlePrevMPage}
                          disabled={currentMPage === 1}
                          sx={{ mr: 2 }}
                        >
                          <ChevronLeftIcon />
                        </Button>
                        <Button
                          variant='contained'
                          onClick={handleNextMPage}
                          disabled={currentMPage === Math.ceil(lists.length / itemsMPerPage)}
                        >
                          <ChevronRightIcon />
                        </Button>
                      </Box>
                    </Box>
                  </Grid>
                </Grid>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </Container>
    </Box>
  )
}

export default PaymentComponent
