import { Paper, Box, Stack, Typography, Avatar, Badge, Button } from '@mui/material'
import { useState, useEffect, useMemo, useCallback } from 'react'
import { MaterialReactTable, type MRT_ColumnDef } from 'material-react-table'
import { useAppSelector, useAppDispatch } from 'src/store/hooks'
import { MainSliceState } from 'src/store/slices/main.slice'
import StyledBadge from 'src/views/custom/StyledBadge'
import { showSnackBar } from 'src/store/slices/snackbar.slice'
import { formatDate } from 'src/utils/custom'
import { useRouter } from 'next/router'

import { useWeb3 } from 'src/utils/context/Web3/web3Context'
import { useUser } from 'src/utils/context/User/UserProvider'
import { showBackdrop, hideBackdrop } from 'src/store/slices/backdrop.slice'

const API_URL = process.env.NEXT_PUBLIC_API_URL

const SentNoteComponent = () => {
  const { onlineStatus } = useAppSelector<MainSliceState>(state => state.main)
  const dispatch = useAppDispatch()
  const { user } = useUser()
  const router = useRouter()

  const { connectState, reclaimBalance } = useWeb3()

  // ** States
  const [list, setList] = useState<Array<any>>([])

  const load_data = useCallback(() => {
    fetch(API_URL + '/notes/sent')
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          setList(data.results)
        } else {
          setList([])
        }
      })
      .catch(error => {
        console.log(error)
        dispatch(showSnackBar({ type: 'error', message: `Error on AJAX call: ${error.toString()}` }))
      })
  }, [dispatch]) // Dependency array for load_data, add dependencies like 'dispatch'

  useEffect(() => {
    load_data()
  }, [load_data]) // Include load_data as a dependency

  // ** Refund handle function
  const refundHandle = useCallback(
    async (row: any) => {
      try {
        // Check logged in
        if (!user) {
          router.push('/pages/login')
        }

        // Send XLM and Note to your fan or project
        // Step 1. Wallet Connect Status Check
        const isConnected = await connectState()

        if (!isConnected) {
          dispatch(showSnackBar({ type: 'error', message: `Please install and connect your wallet` }))

          return
        }

        dispatch(
          showBackdrop({
            message: `Please wait for Refund ...`
          })
        )

        const sendResult = await reclaimBalance(row.sender_wallet, row.balanceId)
        const rowId = row.id

        if (sendResult) {
          try {
            const response = await fetch(`${API_URL}/notes/refund`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json'
              },
              body: JSON.stringify({ rowId })
            })

            const data = await response.json()

            dispatch(hideBackdrop(null))

            if (data.success) {
              dispatch(showSnackBar({ type: 'success', message: `Successfully replied` }))
              console.log('Reply sent successfully:', data)
              load_data()
            } else {
              console.error('Error sending reply:', data.message)
              dispatch(showSnackBar({ type: 'error', message: `Failed with ${data.message}` }))
            }
          } catch (error) {
            console.error('Error:', error)
            dispatch(hideBackdrop(null))
            dispatch(showSnackBar({ type: 'error', message: `Failed to Send. Try again.` }))
          }
        } else {
          dispatch(hideBackdrop(null))
          dispatch(showSnackBar({ type: 'error', message: `Fail to receive xlm token` }))
        }
      } catch (error: any) {
        dispatch(showSnackBar({ type: 'error', message: `Error: ${error.message}` }))
      }
    },
    [dispatch, user, router, connectState, reclaimBalance, load_data]
  )

  const columns = useMemo<MRT_ColumnDef<any>[]>(
    () => [
      {
        accessorKey: 'fullname',
        header: 'Creators',
        Cell: ({ cell }: any) => {
          const row = cell.row.original

          return (
            <Stack direction='row' alignItems={'center'} spacing={4}>
              <StyledBadge
                color={onlineStatus?.[row.expert_id] ? 'success' : 'secondary'}
                variant='standard'
                overlap='circular'
                badgeContent=' '
                anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
              >
                <Avatar
                  alt={`${row.fullname}`}
                  src={row.avatar ?? '/images/avatars/1.png'}
                  sx={{ width: 48, height: 48 }}
                />
              </StyledBadge>
              <Box>
                <Typography variant='body1'>{`${row.fullname}`}</Typography>
                <Stack direction='row' alignItems={'center'} spacing={2}>
                  <Typography variant='caption'>{`sendmeanote.app/c/${row.pagename}`}</Typography>
                </Stack>
              </Box>
            </Stack>
          )
        }
      },
      {
        accessorKey: 'content',
        header: 'Note'
      },
      {
        accessorKey: 'xlm_amount',
        header: 'XLM',
        size: 90
      },
      {
        accessorKey: 'created_at',
        header: 'Date',
        Cell: ({ cell }: any) => {
          const date = cell.getValue() // Get the date value from the cell

          return (
            <Typography variant='body2'>
              {formatDate(date)} {/* Call the formatDate function */}
            </Typography>
          )
        }
      },
      {
        accessorKey: 'is_replied',
        header: 'Status',
        size: 100,
        Cell: ({ cell }: any) => {
          const row = cell.row.original
          const createdAt = row.created_at // Date from the API
          const currentTime = Date.now() // Current time in milliseconds
          const timeDifferenceInHours = (currentTime - new Date(createdAt).getTime()) / (1000 * 60 * 60) // Calculate time difference in hours

          return (
            <Box>
              {row.is_refunded ? (
                <Badge
                  badgeContent='Refunded'
                  color='primary'
                  sx={{
                    pl: 13,
                    '& .MuiBadge-badge': {
                      padding: 3,
                      fontSize: 15,
                      width: 90
                    }
                  }}
                />
              ) : row.is_replied ? (
                <Badge
                  badgeContent='Done'
                  color='success'
                  sx={{
                    pl: 13,
                    '& .MuiBadge-badge': {
                      padding: 3,
                      fontSize: 15,
                      width: 90
                    }
                  }}
                />
              ) : timeDifferenceInHours > 48 ? (
                <Button variant='outlined' onClick={() => refundHandle(row)}>
                  Refund
                </Button>
              ) : (
                <Badge
                  badgeContent='Pending'
                  color='warning'
                  sx={{
                    pl: 13,
                    '& .MuiBadge-badge': {
                      padding: 3,
                      fontSize: 15,
                      width: 90
                    }
                  }}
                />
              )}
            </Box>
          )
        }
      }
    ],
    [onlineStatus, refundHandle]
  )

  // ** Row click handler
  const handleRowClick = async (row: any) => {
    console.log('Clicked', row)
  }

  return (
    <Paper sx={{ width: '100%', overflow: 'hidden' }}>
      <Typography variant='h4' sx={{ textAlign: 'center', mt: 10, textShadow: '2px 2px 4px rgba(0, 0, 0, 0.3)' }}>
        Sent Note to the Creators
      </Typography>

      <Box sx={{ mt: 7 }}>
        <MaterialReactTable
          columns={columns}
          data={list}
          enablePagination
          enableSorting
          enableColumnResizing
          layoutMode='grid'
          initialState={{
            pagination: { pageSize: 5, pageIndex: 0 },
            sorting: [{ id: 'created_at', desc: true }]
          }}
          muiTableBodyRowProps={({ row }) => ({
            hover: true,
            onClick: () => handleRowClick(row), // Add the click handler
            sx: { cursor: 'pointer' } // Add pointer cursor on row hover
          })}
          muiTableProps={{
            sx: {
              '& .MuiTableCell-root': {
                py: 2
              }
            }
          }}
        />
      </Box>
    </Paper>
  )
}

export default SentNoteComponent
