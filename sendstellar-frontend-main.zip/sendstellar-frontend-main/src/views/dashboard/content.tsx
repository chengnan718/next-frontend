import React from 'react'
import { Box, Grid, Container } from '@mui/material'
import Award from './component/award'
import LineChart from './component/linechart'
import DepositWithdraw from './component/withdraw'

const DashboardContent = () => {
  return (
    <Box sx={{ mr: -3 }}>
      <Container>
        <Grid container spacing={5} sx={{ mt: -5 }}>
          <Grid item xs={12} md={12}>
            <Award />
          </Grid>

          <Grid item xs={12} md={6}>
            <LineChart />
          </Grid>

          <Grid item xs={12} md={6}>
            <DepositWithdraw />
          </Grid>
        </Grid>
      </Container>
    </Box>
  )
}

export default DashboardContent
