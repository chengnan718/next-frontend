import {
  Card,
  CardContent,
  Box,
  TextField,
  Button,
  Typography,
  Grid,
  LinearProgress,
  FormControl,
  InputLabel,
  MenuItem
} from '@mui/material'
import React, { useState, useEffect, useCallback, useRef } from 'react'
import { useDropzone, Accept } from 'react-dropzone'
import { useUser } from 'src/utils/context/User/UserProvider'
import { useAppDispatch } from 'src/store/hooks'
import { showBackdrop, hideBackdrop } from 'src/store/slices/backdrop.slice'
import { showSnackBar } from 'src/store/slices/snackbar.slice'
import Select, { SelectChangeEvent } from '@mui/material/Select'
import OutlinedInput from '@mui/material/OutlinedInput'

const API_URL = process.env.NEXT_PUBLIC_API_URL

const ITEM_HEIGHT = 48
const ITEM_PADDING_TOP = 8
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250
    }
  }
}
interface PageState {
  head: string
  intro: string
  file: File | null
}

const PageEditComponent = () => {
  const { user, syncUserInfo } = useUser()
  const dispatch = useAppDispatch()

  const [file, setFile] = useState<File | null>(null)
  const fileInputRef = useRef<HTMLInputElement | null>(null)
  const [uploadProgress, setUploadProgress] = useState<number>(0)
  const [formValues, setFormValues] = useState<PageState>({
    head: '',
    intro: '',
    file: null
  })

  const [formErrors, setFormErrors] = useState({
    head: '',
    intro: '',
    file: ''
  })

  const [personName, setPersonName] = React.useState<string[]>([])

  // Use useCallback to memoize load_data
  const load_data = useCallback(() => {
    fetch(`${API_URL}/pages?id=${user?.id}`)
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          if (data.result) {
            setFormValues({
              head: data.result.head,
              intro: data.result.intro,
              file: data.result.image1
            })
          }
        } else {
          setFormValues({
            head: '',
            intro: '',
            file: null
          })
        }
      })
      .catch(error => {
        dispatch(hideBackdrop(null))
        dispatch(showSnackBar({ type: 'error', message: `Error on AJAX call: ${error.toString()}` }))
      })
  }, [user?.id, dispatch]) // Add dependencies here

  // Now load_data is safely included in the dependency array
  useEffect(() => {
    load_data()
  }, [load_data])

  const validate = () => {
    const errors: any = {}
    if (!formValues.head) {
      errors.head = 'Head is required'
    }
    if (!formValues.intro) {
      errors.intro = 'Description is required'
    }
    setFormErrors(errors)

    return Object.keys(errors).length === 0
  }

  const isConnectWallet = () => {
    if (user?.wallet_address) return true
    else return false
  }

  const handleInputChange = (event: any) => {
    const { name, value } = event.target
    setFormValues(prevValues => ({
      ...prevValues,
      [name]: value
    }))
  }

  const handleChangeType = (event: SelectChangeEvent<typeof personName>) => {
    const {
      target: { value }
    } = event
    setPersonName(typeof value === 'string' ? value.split(',') : value)
  }

  const onDrop = (acceptedFiles: File[]) => {
    setFile(acceptedFiles[0] || null) // Only set the first file

    // Simulate file upload and progress update
    if (acceptedFiles[0]) {
      const uploadTask = setInterval(() => {
        setUploadProgress(prevProgress => {
          const progress = prevProgress + 10
          if (progress >= 100) clearInterval(uploadTask)

          return progress
        })
      }, 500)
    }
  }

  const accept: Accept = {
    'image/*': [],
    'application/pdf': []
  }

  const { getRootProps, getInputProps } = useDropzone({
    onDrop,
    accept,
    multiple: false
  })

  const handleClickDefaultImage = () => {
    setFile({
      name: 'default-image.png',
      lastModified: new Date().getTime(),
      size: 1024,
      type: 'image/png'
    } as File)
  }

  const handleClickUploadedImage = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click() // Trigger file input click
    }
  }

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault()
    if (!validate()) return
    if (!isConnectWallet()) {
      dispatch(showSnackBar({ type: 'error', message: `You have to register your wallet address` }))

      return
    }

    dispatch(
      showBackdrop({
        message: `Please wait...`
      })
    )

    try {
      const formData = new FormData()
      formData.append('head', formValues.head)
      formData.append('intro', formValues.intro)
      formData.append('user_id', user?.id)

      if (file) formData.append('file', file)
      else if (!formValues.file) {
        const errors: any = {}
        errors.file = 'Image is required'
        setFormErrors(errors)
        dispatch(hideBackdrop(null))

        return
      }

      const options = {
        method: 'POST',
        body: formData
      }

      fetch(`${API_URL}/pages/add`, options)
        .then(response => response.json())
        .then(data => {
          dispatch(hideBackdrop(null))
          if (data.success) {
            dispatch(hideBackdrop(null))
            dispatch(showSnackBar({ type: 'success', message: `${data.msg}` }))
            syncUserInfo()
          } else {
            throw new Error(data.msg)
          }
        })
        .catch(error => {
          console.log(error)
        })
    } catch (error) {
      console.error('Error submitting form:', error)
      dispatch(hideBackdrop(null))
      dispatch(showSnackBar({ type: 'error', message: `${error}` }))
    }
  }

  return (
    <Grid container spacing={5}>
      <Grid item xs={12} md={6}>
        <Card
          sx={{
            background: 'linear-gradient(to bottom, #FFFFFF, #f2f6f8)', // Sky-like gradient
            borderRadius: 2,
            pb: 2
          }}
        >
          <CardContent className='flex flex-col gap-2 relative items-start'>
            <Box
              sx={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'flex-end', // Button aligned to the right
                width: '100%',
                mt: 9,
                mb: 5,
                position: 'relative' // Allows us to center the typography
              }}
            >
              {/* Centered Typography */}
              <Typography
                variant='h5'
                sx={{
                  position: 'absolute', // Centers the text horizontally
                  left: '50%',
                  fontWeight: 'bold',
                  transform: 'translateX(-50%)',
                  textShadow: '2px 2px 4px rgba(0, 0, 0, 0.3)'
                }}
              >
                {'Edit Main Page'}
              </Typography>
            </Box>

            <Typography variant='body1' sx={{ textAlign: 'center', mt: 10, mb: 5 }}>
              Please add/edit your page and fund your project and idea!
            </Typography>

            <form noValidate autoComplete='off' onSubmit={handleSubmit}>
              <Grid container spacing={2}>
                <Grid item xs={12} md={12}>
                  <TextField
                    fullWidth
                    id='head'
                    name='head'
                    label='Head'
                    multiline
                    rows={3}
                    sx={{ marginBottom: 4 }}
                    value={formValues.head}
                    onChange={handleInputChange}
                    error={!!formErrors.head}
                    helperText={formErrors.head}
                  />
                </Grid>

                <Grid item xs={12}>
                  <TextField
                    id='intro'
                    name='intro'
                    label='Description'
                    multiline
                    rows={7}
                    fullWidth
                    sx={{ marginBottom: 4 }}
                    value={formValues.intro}
                    onChange={handleInputChange}
                    error={!!formErrors.intro}
                    helperText={formErrors.intro}
                  />
                </Grid>

                <Grid item xs={12}>
                  {!formValues.file ? (
                    <>
                      <Box
                        {...getRootProps()}
                        sx={{
                          border: '2px dashed #ccc',
                          padding: '16px',
                          textAlign: 'center',
                          cursor: 'pointer',
                          marginBottom: 4,
                          borderColor: formErrors.file ? 'red' : '#ccc' // Highlight border if error
                        }}
                      >
                        <input {...getInputProps()} />
                        <p>Drag & drop image or video here, or click</p>
                      </Box>

                      <Typography>
                        If you want to use the default image, click{' '}
                        <span
                          onClick={handleClickDefaultImage}
                          style={{ textDecoration: 'underline', cursor: 'pointer' }}
                        >
                          here
                        </span>
                      </Typography>

                      {formErrors.file && (
                        <Typography color='error' sx={{ mt: 2, fontSize: 14 }}>
                          {formErrors.file}
                        </Typography>
                      )}

                      {/* Display selected files and upload progress */}
                      {file && (
                        <Box sx={{ marginBottom: 2 }}>
                          <p>{file.name}</p>
                          <LinearProgress variant='determinate' value={uploadProgress} />
                        </Box>
                      )}
                    </>
                  ) : (
                    <>
                      <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', mt: -3 }}>
                          <p style={{ marginRight: '12px' }}>Uploaded File:</p>
                          <span
                            onClick={handleClickUploadedImage}
                            style={{ textDecoration: 'underline', cursor: 'pointer' }}
                          >
                            {formValues.file}
                          </span>
                        </Box>

                        {/* File name and LinearProgress vertically aligned */}
                        {file && (
                          <Box sx={{ marginBottom: 2, width: '100%', mt: -3 }}>
                            <p>{file.name}</p>
                            <LinearProgress variant='determinate' value={uploadProgress} />
                          </Box>
                        )}

                        {/* Hidden file input */}
                        <input
                          type='file'
                          {...getInputProps()}
                          ref={fileInputRef}
                          style={{ display: 'none' }} // Hide the file input
                        />
                      </Box>
                    </>
                  )}
                </Grid>

                <Grid item xs={12} sx={{ textAlign: 'right' }}>
                  <Button type='submit' variant='contained' sx={{ width: '150px', mt: 2 }}>
                    Publish
                  </Button>
                </Grid>
              </Grid>
            </form>
          </CardContent>
        </Card>
      </Grid>
      <Grid item xs={12} md={6}>
        <Card
          sx={{
            background: 'linear-gradient(to bottom, #FFFFFF, #f2f6f8)', // Sky-like gradient
            borderRadius: 2,
            pb: 2
          }}
        >
          <CardContent className='flex flex-col gap-2 relative items-start'>
            <Box
              sx={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'flex-end', // Button aligned to the right
                width: '100%',
                mt: 9,
                mb: 5,
                position: 'relative' // Allows us to center the typography
              }}
            >
              {/* Centered Typography */}
              <Typography
                variant='h5'
                sx={{
                  position: 'absolute', // Centers the text horizontally
                  left: '50%',
                  fontWeight: 'bold',
                  transform: 'translateX(-50%)',
                  textShadow: '2px 2px 4px rgba(0, 0, 0, 0.3)'
                }}
              >
                {'Add Post'}
              </Typography>
            </Box>
            <form noValidate autoComplete='off'>
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <FormControl fullWidth sx={{ marginBottom: 4, mt: 16 }}>
                    <InputLabel id='select-label'>Type</InputLabel>
                    <Select
                      labelId='demo-multiple-name-label'
                      id='demo-multiple-name'
                      value={personName}
                      onChange={handleChangeType}
                      input={<OutlinedInput label='Name' />}
                      MenuProps={MenuProps}
                    >
                      <MenuItem value='blog'>Blog</MenuItem>
                      <MenuItem value='photo'>Photo</MenuItem>
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item xs={12} md={12}>
                  <TextField
                    fullWidth
                    id='title'
                    name='title'
                    label='Title'
                    multiline
                    rows={2}
                    sx={{ marginBottom: 4 }}
                  />
                </Grid>
                <Grid item xs={12} md={12}>
                  <TextField
                    fullWidth
                    id='content'
                    name='content'
                    label='Content'
                    multiline
                    rows={4}
                    sx={{ marginBottom: 4 }}
                  />
                </Grid>
                <Grid item xs={12} md={12}>
                  <Box
                    sx={{
                      border: '2px dashed #ccc',
                      padding: '16px',
                      textAlign: 'center',
                      cursor: 'pointer',
                      marginBottom: 4
                    }}
                  >
                    <input {...getInputProps()} />
                    <p>Drag & drop image or video here, or click</p>
                  </Box>
                </Grid>

                <Grid item xs={12} sx={{ textAlign: 'right' }}>
                  <Button type='submit' variant='contained' sx={{ width: '150px', mt: 2 }}>
                    Add
                  </Button>
                </Grid>
              </Grid>
            </form>
          </CardContent>
        </Card>
      </Grid>
    </Grid>
  )
}

export default PageEditComponent
