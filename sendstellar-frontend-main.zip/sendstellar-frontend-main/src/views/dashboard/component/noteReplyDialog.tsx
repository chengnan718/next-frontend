// src/components/NoteDialog.tsx
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Typography,
  Box,
  Grid,
  TextField
} from '@mui/material'
import { formatDate } from 'src/utils/custom'
import {
  CheckCircle,
  HourglassEmpty,
  MonetizationOn,
  CalendarMonth,
  EditNoteOutlined,
  ReplyOutlined
} from '@mui/icons-material'
import { useEffect, useState } from 'react'
import { showBackdrop, hideBackdrop } from 'src/store/slices/backdrop.slice'
import { useAppDispatch } from 'src/store/hooks'
import { showSnackBar } from 'src/store/slices/snackbar.slice'
import { useRouter } from 'next/router'

import { useWeb3 } from 'src/utils/context/Web3/web3Context'
import { useUser } from 'src/utils/context/User/UserProvider'

const API_URL = process.env.NEXT_PUBLIC_API_URL

interface NoteDialogProps {
  open: boolean
  noteData: any | null
  onClose: () => void
  onReplySent: () => void
}

const NoteReplyDialog: React.FC<NoteDialogProps> = ({ open, noteData, onClose, onReplySent }) => {
  const [reply, setReply] = useState('')
  const dispatch = useAppDispatch()
  const router = useRouter()
  const { user } = useUser()

  const { connectState, claimBlance } = useWeb3()

  // Reset reply when the dialog opens or noteData changes
  useEffect(() => {
    if (open) {
      setReply('')
      setFormErrors({ reply: '' })
    }
  }, [open, noteData])

  const [formErrors, setFormErrors] = useState({
    reply: ''
  })

  const sendReply = async (event: React.FormEvent) => {
    event.preventDefault()

    if (!reply) {
      const errors: any = {}
      errors.reply = 'Input the reply note'
      setFormErrors(errors)

      return
    }

    // Check logged in
    if (!user) {
      router.push('/pages/login')
    }

    // Send XLM and Note to your fan or project
    // Step 1. Wallet Connect Status Check
    const isConnected = await connectState()

    if (!isConnected) {
      dispatch(showSnackBar({ type: 'error', message: `Please install and connect your wallet` }))

      return
    }

    const note_id = noteData.id
    const reply_content = reply

    dispatch(
      showBackdrop({
        message: `Please wait for reply ...`
      })
    )

    const sendResult = await claimBlance(noteData.receiver_wallet, noteData.balanceId)

    if (sendResult) {
      try {
        const response = await fetch(`${API_URL}/notes/reply`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ note_id, reply_content })
        })

        const data = await response.json()

        dispatch(hideBackdrop(null))

        if (data.success) {
          dispatch(
            showSnackBar({ type: 'success', message: `Successfully replied and received ${noteData.xlm_amount} XLMs` })
          )
          console.log('Reply sent successfully:', data)
          onReplySent()
          onClose()
        } else {
          console.error('Error sending reply:', data.message)
          dispatch(showSnackBar({ type: 'error', message: `Failed with ${data.message}` }))
        }
      } catch (error) {
        console.error('Error:', error)
        dispatch(hideBackdrop(null))
        dispatch(showSnackBar({ type: 'error', message: `Failed to Send. Try again.` }))
      }
    } else {
      dispatch(hideBackdrop(null))
      dispatch(showSnackBar({ type: 'error', message: `Fail to receive xlm token` }))
    }
  }

  return (
    <Dialog open={open} fullWidth maxWidth='sm'>
      <DialogTitle sx={{ background: '#1976d2' }}>
        <Typography variant='h5' sx={{ color: 'white', fontSize: '2rem', ml: 2 }}>
          View Details
        </Typography>
      </DialogTitle>
      <DialogContent dividers>
        {noteData && (
          <Box sx={{ p: 2 }}>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <Typography variant='h6' sx={{ fontWeight: 'bold', mb: 1 }}>
                  Supporter Name: <span style={{ marginLeft: 10 }}>{noteData.fullname}</span>
                </Typography>
              </Grid>
              <Grid item xs={12}>
                <Typography variant='body1' sx={{ mb: 5 }}>
                  PageName: {`sendmeanote.app/a/`}
                  {noteData.pagename}
                </Typography>
              </Grid>
              <Grid item xs={12}>
                <Grid container spacing={1}>
                  <Grid item xs={2} sx={{ display: 'flex', alignItems: 'center' }}>
                    <MonetizationOn fontSize='medium' sx={{ mr: 2, color: '#1976d2' }} />
                    <Typography variant='body1'>XLM:</Typography>
                  </Grid>
                  <Grid item xs={10}>
                    <Typography variant='body1'>
                      {noteData.xlm_amount}
                      {`XLM`}
                    </Typography>
                  </Grid>
                </Grid>
              </Grid>
              <Grid item xs={12}>
                <Typography variant='body1' sx={{ mb: 1 }}>
                  {noteData.is_refunded ? (
                    <>
                      <CheckCircle color='success' sx={{ mr: 1, mb: '-6px' }} />
                      Status: <span style={{ marginLeft: 7 }}>Refunded</span>
                    </>
                  ) : noteData.is_replied ? (
                    <>
                      <CheckCircle color='success' sx={{ mr: 1, mb: '-6px' }} />
                      Status: <span style={{ marginLeft: 7 }}>Replied</span>
                    </>
                  ) : (
                    <>
                      <HourglassEmpty color='warning' sx={{ mr: 1, mb: '-6px' }} />
                      Status: <span style={{ marginLeft: 7 }}>Waiting</span>
                    </>
                  )}
                </Typography>
              </Grid>
              <Grid item xs={12}>
                <Grid container spacing={1}>
                  <Grid item xs={2} sx={{ display: 'flex', alignItems: 'center' }}>
                    <CalendarMonth fontSize='medium' sx={{ mr: 2, color: '#1976d2' }} />
                    <Typography variant='body1'>Date:</Typography>
                  </Grid>
                  <Grid item xs={10}>
                    <Typography variant='body1'>{formatDate(noteData.created_at)}</Typography>
                  </Grid>
                </Grid>
              </Grid>
              <Grid item xs={12}>
                <Grid container spacing={1}>
                  <Grid item xs={2} sx={{ display: 'flex', alignItems: 'center' }}>
                    <EditNoteOutlined fontSize='medium' sx={{ mr: 2, color: '#1976d2' }} />
                    <Typography variant='body1'>Note:</Typography>
                  </Grid>
                  <Grid item xs={10}>
                    <Typography variant='body1' sx={{ mb: 1, background: '#e5ebfa', padding: 3 }}>
                      {noteData.content}
                    </Typography>
                  </Grid>
                </Grid>
              </Grid>
              {noteData.is_refunded ? (
                <Grid item xs={12} sx={{ mt: 5 }}></Grid>
              ) : noteData.is_replied ? (
                <Grid item xs={12} sx={{ mt: 5 }}>
                  <Grid container spacing={1}>
                    <Grid item xs={2} sx={{ display: 'flex', alignItems: 'center' }}>
                      <ReplyOutlined fontSize='medium' sx={{ mr: 2, color: '#1976d2' }} />
                      <Typography variant='body1'>Reply:</Typography>
                    </Grid>
                    <Grid item xs={10}>
                      <Typography variant='body1' sx={{ mb: 1, background: '#e5ebfa', padding: 3 }}>
                        {noteData.reply_content}
                      </Typography>
                    </Grid>
                  </Grid>
                </Grid>
              ) : (
                <Grid item xs={12} sx={{ mt: 5 }}>
                  <TextField
                    fullWidth
                    id='reply'
                    name='reply'
                    label='Reply'
                    multiline
                    rows={2}
                    value={reply}
                    onChange={e => setReply(e.target.value)}
                    error={!!formErrors.reply}
                    helperText={formErrors.reply}
                  />
                </Grid>
              )}
            </Grid>
          </Box>
        )}
      </DialogContent>
      <DialogActions sx={{ mt: 5 }}>
        <Button onClick={onClose} color='primary' variant='outlined' size='medium'>
          Close
        </Button>
        <Button onClick={sendReply} color='primary' variant='contained' size='medium'>
          Send
        </Button>
      </DialogActions>
    </Dialog>
  )
}

export default NoteReplyDialog
