// MUI Imports
import Card from '@mui/material/Card'
import CardHeader from '@mui/material/CardHeader'
import CardContent from '@mui/material/CardContent'
import Typography from '@mui/material/Typography'
import Grid from '@mui/material/Grid'

const withdrawData = [
  {
    amount: '-$145',
    title: 'Google Adsense',
    subtitle: '2024.1.25',
    logo: '/images/logos/stellar.png'
  },
  {
    amount: '-$1870',
    title: 'Github Enterprise',
    logo: '/images/logos/stellar.png',
    subtitle: '2024.1.25'
  },
  {
    amount: '-$450',
    title: 'Upgrade Slack Plan',
    subtitle: '2024.1.25',
    logo: '/images/logos/stellar.png'
  },
  {
    amount: '-$540',
    title: 'Digital Ocean',
    subtitle: '2024.1.25',
    logo: '/images/logos/stellar.png'
  },
  {
    amount: '-$540',
    title: 'Digital Ocean',
    subtitle: '2024.1.25',
    logo: '/images/logos/stellar.png'
  }
]

const DepositWithdraw = () => {
  return (
    <Card
      sx={{
        background: 'linear-gradient(to bottom, #FFFFFF, #f2f6f8)', // Sky-like gradient
        borderRadius: 2,
        pb: 2,
        height: '400px',
        overflowY: 'auto'
      }}
    >
      <Grid container>
        <Grid item xs={12} md={12}>
          <CardHeader title={<Typography sx={{ color: '#127C71', fontSize: '1.7rem' }}>Withdraw</Typography>} />
          <CardContent>
            {withdrawData.map((item, index) => (
              <Grid container key={index} alignItems='center' spacing={2} sx={{ p: 1.2 }}>
                <Grid item xs={2}>
                  <img
                    src={item.logo}
                    alt={item.title}
                    style={{ width: '40px', height: '40px', objectFit: 'contain' }}
                  />
                </Grid>
                <Grid item xs={6}>
                  <Typography color='text.primary' className='font-medium'>
                    {item.title}
                  </Typography>
                  <Typography>{item.subtitle}</Typography>
                </Grid>
                <Grid item xs={4} style={{ textAlign: 'right' }}>
                  <Typography color='error.main' className='font-medium'>
                    {item.amount}
                  </Typography>
                </Grid>
              </Grid>
            ))}
          </CardContent>
        </Grid>
      </Grid>
    </Card>
  )
}

export default DepositWithdraw
