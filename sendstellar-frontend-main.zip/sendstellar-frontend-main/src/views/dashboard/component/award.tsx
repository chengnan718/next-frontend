// MUI Imports
import { Card, Box, Avatar, Stack, Badge, Grid } from '@mui/material'
import CardContent from '@mui/material/CardContent'
import Typography from '@mui/material/Typography'
import Button from '@mui/material/Button'
import { useUser } from 'src/utils/context/User/UserProvider'
import { styled } from '@mui/material/styles'

const StyledBadge = styled(Badge)(({ theme }) => ({
  '& .MuiBadge-badge': {
    backgroundColor: '#44b700',
    color: '#44b700',
    boxShadow: `0 0 0 2px ${theme.palette.background.paper}`,
    '&::after': {
      position: 'absolute',
      top: 0,
      left: 0,
      width: '100%',
      height: '100%',
      borderRadius: '50%',
      animation: 'ripple 1.2s infinite ease-in-out',
      border: '1px solid currentColor',
      content: '""'
    }
  },
  '@keyframes ripple': {
    '0%': {
      transform: 'scale(.8)',
      opacity: 1
    },
    '100%': {
      transform: 'scale(2.4)',
      opacity: 0
    }
  }
}))

const Award = () => {
  const { user } = useUser()

  return (
    <Card
      sx={{
        background: 'linear-gradient(to bottom, #FFFFFF, #f2f6f8)', // Sky-like gradient
        borderRadius: 2,
        pb: 2
      }}
    >
      <CardContent className='flex flex-col gap-2 relative items-start'>
        <Box sx={{ pl: 4, pr: 4, pt: 3 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <Box sx={{ display: 'flex', alignItems: 'center' }}>
              <Stack direction='row' spacing={2}>
                <StyledBadge
                  overlap='circular'
                  anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                  variant='dot'
                  sx={{
                    '& .MuiBadge-dot': {
                      width: 16, // Increase dot size
                      height: 16, // Increase dot size
                      borderRadius: '50%'
                    }
                  }}
                >
                  <Avatar
                    alt='Remy Sharp'
                    src={user?.avatar ?? '/images/avatars/1.png'}
                    sx={{ width: 70, height: 70 }}
                  />
                </StyledBadge>
              </Stack>
              <Box sx={{ ml: 7 }}>
                {' '}
                {/* Add some margin to separate the text from the avatar */}
                <Typography variant='h4'>Hi! {user?.fullname}</Typography>
                <Typography>
                  {`sendmeanote.app/c/`}
                  {user?.pagename}
                </Typography>
              </Box>
            </Box>

            {/* Add button to the right */}
            <Button variant='contained' size='medium'>
              Share MyPage
            </Button>
          </Box>
        </Box>

        <Box sx={{ pl: 4, pr: 4, pt: 7 }}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={4}>
              <Typography variant='h6' color='textSecondary'>
                Total Earning
              </Typography>
              <Box sx={{ position: 'relative', display: 'inline-block', mt: 2 }}>
                <Typography variant='h4' color='primary'>
                  $42.8k
                </Typography>

                <Typography
                  variant='body2'
                  color='error.main'
                  sx={{
                    position: 'absolute',
                    top: 0,
                    right: -55,
                    fontSize: '1.0rem'
                  }}
                >
                  +0.5K
                </Typography>
              </Box>
            </Grid>
            <Grid item xs={12} md={4}>
              <Typography variant='h6' color='textSecondary'>
                Answer Note
              </Typography>
              <Box sx={{ position: 'relative', display: 'inline-block', mt: 2 }}>
                <Typography variant='h4' color='primary'>
                  3
                </Typography>

                <Typography
                  variant='body2'
                  color='error.main'
                  sx={{
                    position: 'absolute',
                    top: 0,
                    right: -25,
                    fontSize: '1.0rem'
                  }}
                >
                  +1
                </Typography>
              </Box>
            </Grid>
            <Grid item xs={12} md={4}>
              <Typography variant='h6' color='textSecondary'>
                Total Supporters
              </Typography>
              <Box sx={{ position: 'relative', display: 'inline-block', mt: 2 }}>
                <Typography variant='h4' color='primary'>
                  150
                </Typography>

                <Typography
                  variant='body2'
                  color='error.main'
                  sx={{
                    position: 'absolute',
                    top: 0,
                    right: -30,
                    fontSize: '1.0rem'
                  }}
                >
                  +7
                </Typography>
              </Box>
            </Grid>
          </Grid>
        </Box>
        <Box sx={{ pl: 4, pr: 4, pt: 3 }}>
          <Grid container spacing={2}>
            <Grid item xs={12} md={4}>
              <Button size='small' variant='outlined'>
                View History
              </Button>
            </Grid>
            <Grid item xs={12} md={4}>
              <Button size='small' variant='outlined'>
                View Detail
              </Button>
            </Grid>
            <Grid item xs={12} md={4}>
              <Button size='small' variant='outlined'>
                View Detail
              </Button>
            </Grid>
          </Grid>
        </Box>
      </CardContent>
    </Card>
  )
}

export default Award
