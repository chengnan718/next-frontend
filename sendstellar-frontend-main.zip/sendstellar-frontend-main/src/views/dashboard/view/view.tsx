const PageViewComponent = () => {
  return (
    <>
      <h1>View</h1>
    </>
  )
}

export default PageViewComponent
