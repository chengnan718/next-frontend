import React, { useState } from 'react'
import { Card, CardContent, Box, Typography, Button, Switch, Select, MenuItem } from '@mui/material'

const SettingComponent = () => {
  const [selectedColor, setSelectedColor] = useState('#FF0000')
  const [isDarkMode, setIsDarkMode] = useState(false)
  const [currency, setCurrency] = useState('USD')

  const handleCurrencyChange = (event: any) => {
    setCurrency(event.target.value)
  }

  const handleColorChange = (color: string) => {
    setSelectedColor(color)
  }

  const handleModeToggle = () => {
    setIsDarkMode(prevMode => !prevMode)
  }

  return (
    <Card
      sx={{
        borderRadius: 2,
        pb: 2,
        color: isDarkMode ? '#FFFFFF' : '#000000',
        background: 'linear-gradient(to bottom, #FFFFFF, #f2f6f8)' // Sky-like gradient
      }}
    >
      <CardContent className='flex flex-col gap-2 relative items-start'>
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'flex-end',
            width: '100%',
            mt: 10,
            mb: 10,
            position: 'relative'
          }}
        >
          {/* Centered Typography */}
          <Typography
            variant='h4'
            sx={{
              position: 'absolute',
              left: '50%',
              transform: 'translateX(-50%)'
            }}
          >
            {'Settings'}
          </Typography>
        </Box>

        {/* Color Setting Box */}
        <Box sx={{ display: 'flex', gap: 2, justifyContent: 'left', mt: 20, ml: 10 }}>
          <Typography variant='h5' color='textSecondary' sx={{ mr: 15 }}>
            Color
          </Typography>
          {['#FF0000', '#00FF00', '#0000FF', '#FFFF00', '#FF00FF'].map((color, index) => (
            <Box
              key={index}
              onClick={() => handleColorChange(color)}
              sx={{
                width: 40,
                height: 40,
                ml: 5,
                mt: -1,
                backgroundColor: color,
                borderRadius: '50%',
                cursor: 'pointer',
                border: `2px solid ${color === selectedColor ? '#000000' : 'transparent'}`
              }}
            />
          ))}
          <Button variant='outlined' sx={{ ml: 80 }}>
            Apply
          </Button>
        </Box>

        <Typography variant='body1' color='textSecondary' sx={{ ml: 15, mt: 3 }}>
          Set the color of the published page. You can preview the selected color under the box. Please click the apply.
        </Typography>

        {/* Page Style Settings */}
        <Box sx={{ mt: 10, display: 'flex', justifyContent: 'center' }}>
          <Button
            variant='outlined'
            sx={{
              mt: 1,
              width: 150,
              height: 150,
              backgroundColor: selectedColor,
              color: isDarkMode ? '#FFFFFF' : '#000000',
              '&:hover': {
                backgroundColor: selectedColor
              }
            }}
          ></Button>
        </Box>

        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 10, ml: 10 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            <Typography variant='h5' color='textSecondary'>
              Localized pricing
            </Typography>
            <Switch
              checked={isDarkMode}
              onChange={handleModeToggle}
              color='primary'
              inputProps={{ 'aria-label': 'controlled day/night mode' }}
              sx={{ ml: 3, mt: 1 }}
            />
          </Box>

          <Typography variant='body1' color='textSecondary' sx={{ ml: 5 }}>
            Enable localized pricing so your supporters can pay in their local currency.
          </Typography>
        </Box>

        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 10, ml: 10 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            <Typography variant='h5' color='textSecondary'>
              MoneyGram Payout Currency
            </Typography>
            <Select value={currency} onChange={handleCurrencyChange} sx={{ minWidth: 170, ml: 20 }} size='small'>
              <MenuItem value='USD'>USD</MenuItem>
              <MenuItem value='EUR'>EUR</MenuItem>
              <MenuItem value='GBP'>GBP</MenuItem>
            </Select>
          </Box>
          <Typography variant='body1' color='textSecondary' sx={{ ml: 5 }}>
            You will withdraw your earnings in this currency by Moneygram.
          </Typography>
        </Box>
      </CardContent>
    </Card>
  )
}

export default SettingComponent
