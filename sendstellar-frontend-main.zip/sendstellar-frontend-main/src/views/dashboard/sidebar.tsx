import React, { useState, useCallback, useEffect } from 'react'
import { useAppDispatch } from 'src/store/hooks'
import { Box, List, ListItem, ListItemText, Typography, AppBar, Toolbar, IconButton, ListItemIcon } from '@mui/material'
import Container from '@mui/material/Container'
import MenuIcon from '@mui/icons-material/Menu'
import HomeIcon from '@mui/icons-material/Home'
import EditIcon from '@mui/icons-material/Edit'
import SupportIcon from '@mui/icons-material/Help'
import { useRouter } from 'next/router'
import Divider from '@mui/material/Divider'
import PaymentsIcon from '@mui/icons-material/Payments'
import PeopleIcon from '@mui/icons-material/People'
import { useUser } from 'src/utils/context/User/UserProvider'
import SendIcon from '@mui/icons-material/NearMe'
import ReplyIcon from '@mui/icons-material/TaskAlt'
import VisibilityIcon from '@mui/icons-material/Visibility'
import SettingsApplicationsIcon from '@mui/icons-material/SettingsApplications'
import { showSnackBar } from 'src/store/slices/snackbar.slice'

const DashboardMenu = () => {
  const [selectedItem, setSelectedItem] = useState('Home')
  const router = useRouter()
  const { user } = useUser()
  const dispatch = useAppDispatch()

  useEffect(() => {
    const pathToMenuItemMap: Record<string, string> = {
      '/dashboard': 'Home',
      '/dashboard/edit': 'Edit',
      '/dashboard/answer': 'Answer',
      '/dashboard/view': 'View',
      '/dashboard/sent': 'Sent',
      '/dashboard/explore': 'Explore',
      '/dashboard/supporter': 'Supporters',
      '/dashboard/payment': 'Payments',
      '/dashboard/settings': 'Settings'
    }

    // Get the current menu item based on the path
    const currentItem = pathToMenuItemMap[router.pathname] || 'Home'
    setSelectedItem(currentItem)
  }, [router.pathname])

  const handleMenuClick = useCallback(
    (item: string, path: string) => {
      if (item !== selectedItem) {
        setSelectedItem(item)
        router.push(path)
      }
    },
    [selectedItem, router]
  )

  const viewPublishPage = () => {
    if (user && !user.wallet_address) {
      dispatch(showSnackBar({ type: 'error', message: `You have to register your wallet address` }))

      return
    }
    if (!user?.is_creator) {
      dispatch(showSnackBar({ type: 'error', message: `You have to publish your page` }))

      return
    }

    // Open the URL in a new tab
    window.open('/c/' + user?.pagename, '_blank', 'noopener,noreferrer')
  }

  return (
    <Box sx={{ width: '100%' }}>
      <Container>
        <Box sx={{ flexGrow: 1 }}>
          <AppBar position='static'>
            <Toolbar sx={{ background: '#1976d2' }}>
              <IconButton size='large' edge='start' color='inherit' aria-label='menu' sx={{ mr: 2 }}>
                <MenuIcon />
              </IconButton>
              <Typography variant='h6' component='div' color='white' sx={{ flexGrow: 1 }}>
                Menu
              </Typography>
            </Toolbar>
          </AppBar>
        </Box>
        <List sx={{ ml: -1 }}>
          <ListItem
            button
            onClick={() => handleMenuClick('Home', '/dashboard')}
            sx={{
              backgroundColor: selectedItem === 'Home' ? '#e5ebfa' : 'transparent',
              borderRadius: 1,
              mt: 4
            }}
          >
            <ListItemIcon>
              <HomeIcon />
            </ListItemIcon>
            <ListItemText primary='Home' />
          </ListItem>

          <ListItem
            button
            onClick={() => handleMenuClick('Edit', '/dashboard/edit')}
            sx={{
              backgroundColor: selectedItem === 'Edit' ? '#e5ebfa' : 'transparent',
              borderRadius: 1
            }}
          >
            <ListItemIcon>
              <EditIcon />
            </ListItemIcon>
            <ListItemText primary='Edit Page' />
          </ListItem>

          <ListItem
            button
            onClick={() => viewPublishPage()}
            sx={{
              backgroundColor: selectedItem === 'View' ? '#e5ebfa' : 'transparent',
              borderRadius: 1
            }}
          >
            <ListItemIcon>
              <VisibilityIcon />
            </ListItemIcon>
            <ListItemText primary='View Page' />
          </ListItem>

          {user?.is_creator && (
            <ListItem
              button
              onClick={() => handleMenuClick('Answer', '/dashboard/answer')}
              sx={{
                backgroundColor: selectedItem === 'Answer' ? '#e5ebfa' : 'transparent',
                borderRadius: 1
              }}
            >
              <ListItemIcon>
                <ReplyIcon />
              </ListItemIcon>
              <ListItemText primary='Reply Note' />
            </ListItem>
          )}

          <ListItem
            button
            onClick={() => handleMenuClick('Sent', '/dashboard/sent')}
            sx={{
              backgroundColor: selectedItem === 'Sent' ? '#e5ebfa' : 'transparent',
              borderRadius: 1
            }}
          >
            <ListItemIcon>
              <SendIcon />
            </ListItemIcon>
            <ListItemText primary='Sent Note' />
          </ListItem>

          <ListItem
            button
            onClick={() => handleMenuClick('Explore', '/dashboard/explore')}
            sx={{
              backgroundColor: selectedItem === 'Explore' ? '#e5ebfa' : 'transparent',
              borderRadius: 1
            }}
          >
            <ListItemIcon>
              <PeopleIcon />
            </ListItemIcon>
            <ListItemText primary='Explore Creators' />
          </ListItem>

          <ListItem
            button
            onClick={() => handleMenuClick('Supporters', '/dashboard/supporter')}
            sx={{
              backgroundColor: selectedItem === 'Supporters' ? '#e5ebfa' : 'transparent',
              borderRadius: 1
            }}
          >
            <ListItemIcon>
              <SupportIcon />
            </ListItemIcon>
            <ListItemText primary='Supporters' />
          </ListItem>

          <ListItem
            button
            onClick={() => handleMenuClick('Payments', '/dashboard/payment')}
            sx={{
              backgroundColor: selectedItem === 'Payments' ? '#e5ebfa' : 'transparent',
              borderRadius: 1,
              ml: 1
            }}
          >
            <ListItemIcon>
              <PaymentsIcon />
            </ListItemIcon>
            <ListItemText primary='Payments' />
          </ListItem>

          <Divider sx={{ my: 5 }}></Divider>

          <ListItem
            button
            onClick={() => handleMenuClick('Settings', '/dashboard/settings')}
            sx={{
              backgroundColor: selectedItem === 'Settings' ? '#e5ebfa' : 'transparent',
              borderRadius: 1,
              ml: 1
            }}
          >
            <ListItemIcon>
              <SettingsApplicationsIcon />
            </ListItemIcon>
            <ListItemText primary='Settings' />
          </ListItem>
        </List>
      </Container>
    </Box>
  )
}

export default DashboardMenu
