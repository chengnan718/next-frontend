import { Paper, Box, Stack, Typography, Avatar, Badge } from '@mui/material'
import { useState, useEffect, useMemo, useCallback } from 'react'
import { MaterialReactTable, type MRT_ColumnDef } from 'material-react-table'
import { useAppSelector, useAppDispatch } from 'src/store/hooks'
import { MainSliceState } from 'src/store/slices/main.slice'
import StyledBadge from 'src/views/custom/StyledBadge'
import { showSnackBar } from 'src/store/slices/snackbar.slice'
import { formatDate } from 'src/utils/custom'
import NoteReplyDialog from '../component/noteReplyDialog'

const API_URL = process.env.NEXT_PUBLIC_API_URL

const AnswerNoteComponent = () => {
  const { onlineStatus } = useAppSelector<MainSliceState>(state => state.main)
  const dispatch = useAppDispatch()

  // ** States
  const [list, setList] = useState<Array<any>>([])
  const [selectedRow, setSelectedRow] = useState<any>(null)
  const [openModal, setOpenModal] = useState<boolean>(false)

  const load_data = useCallback(() => {
    fetch(API_URL + '/notes')
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          setList(data.results)
        } else {
          setList([])
        }
      })
      .catch(error => {
        console.log(error)
        dispatch(showSnackBar({ type: 'error', message: `Error on AJAX call: ${error.toString()}` }))
      })
  }, [dispatch]) // Dependency array for load_data, add dependencies like 'dispatch'

  useEffect(() => {
    load_data()
  }, [load_data]) // Include load_data as a dependency

  // ** Callback for refreshing data
  const handleReplySent = () => {
    load_data()
  }

  const columns = useMemo<MRT_ColumnDef<any>[]>(
    () => [
      {
        accessorKey: 'fullname',
        header: 'From',
        Cell: ({ cell }: any) => {
          const row = cell.row.original

          return (
            <Stack direction='row' alignItems={'center'} spacing={4}>
              <StyledBadge
                color={onlineStatus?.[row.expert_id] ? 'success' : 'secondary'}
                variant='standard'
                overlap='circular'
                badgeContent=' '
                anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
              >
                <Avatar
                  alt={`${row.fullname}`}
                  src={row.avatar ?? '/images/avatars/1.png'}
                  sx={{ width: 48, height: 48 }}
                />
              </StyledBadge>
              <Box>
                <Typography variant='body1'>{`${row.fullname}`}</Typography>
                <Stack direction='row' alignItems={'center'} spacing={2}>
                  <Typography variant='caption'>{`sendmeanote.app/c/${row.pagename}`}</Typography>
                </Stack>
              </Box>
            </Stack>
          )
        }
      },
      {
        accessorKey: 'content',
        header: 'Note'
      },
      {
        accessorKey: 'xlm_amount',
        header: 'XLM',
        size: 90
      },
      {
        accessorKey: 'created_at',
        header: 'Date',
        Cell: ({ cell }: any) => {
          const date = cell.getValue() // Get the date value from the cell

          return (
            <Typography variant='body2'>
              {formatDate(date)} {/* Call the formatDate function */}
            </Typography>
          )
        }
      },
      {
        accessorKey: 'is_replied',
        header: 'Status',
        size: 100,
        Cell: ({ cell }: any) => {
          const row = cell.row.original

          return (
            <Box>
              {row.is_refunded ? (
                <Badge
                  badgeContent='Refunded'
                  color='primary'
                  sx={{
                    pl: 13,
                    '& .MuiBadge-badge': {
                      padding: 3,
                      fontSize: 15,
                      width: 90
                    }
                  }}
                />
              ) : row.is_replied ? (
                <Badge
                  badgeContent='Replied'
                  color='success'
                  sx={{
                    pl: 13,
                    '& .MuiBadge-badge': {
                      padding: 3,
                      fontSize: 15,
                      width: 90
                    }
                  }}
                />
              ) : (
                <Badge
                  badgeContent='Waiting'
                  color='warning'
                  sx={{
                    pl: 13,
                    '& .MuiBadge-badge': {
                      padding: 3,
                      fontSize: 15,
                      width: 90
                    }
                  }}
                />
              )}
            </Box>
          )
        }
      }
    ],
    [onlineStatus]
  )

  // ** Row click handler
  const handleRowClick = (row: any) => {
    console.log('Row Data', row.original)
    setSelectedRow(row.original) // Store the selected row data
    setOpenModal(true) // Open the modal
  }

  // ** Handle modal close
  const handleCloseModal = () => {
    setOpenModal(false)
    setSelectedRow(null)
  }

  return (
    <>
      <Paper sx={{ width: '100%', overflow: 'hidden' }}>
        <Typography variant='h4' sx={{ textAlign: 'center', mt: 10, textShadow: '2px 2px 4px rgba(0, 0, 0, 0.3)' }}>
          Reploy Note from Supporters
        </Typography>

        <Box sx={{ mt: 7 }}>
          <MaterialReactTable
            columns={columns}
            data={list}
            enablePagination
            enableSorting
            enableColumnResizing
            layoutMode='grid'
            initialState={{
              pagination: { pageSize: 5, pageIndex: 0 },
              sorting: [{ id: 'created_at', desc: true }]
            }}
            muiTableBodyRowProps={({ row }) => ({
              hover: true,
              onClick: () => handleRowClick(row), // Add the click handler
              sx: { cursor: 'pointer' } // Add pointer cursor on row hover
            })}
            muiTableProps={{
              sx: {
                '& .MuiTableCell-root': {
                  py: 2
                }
              }
            }}
          />
        </Box>
      </Paper>

      {/* Use the NoteDialog component */}
      <NoteReplyDialog
        open={openModal}
        noteData={selectedRow}
        onClose={handleCloseModal}
        onReplySent={handleReplySent}
      />
    </>
  )
}

export default AnswerNoteComponent
