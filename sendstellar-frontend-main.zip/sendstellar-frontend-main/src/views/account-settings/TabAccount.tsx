// ** React Imports
import { useState, useEffect } from 'react'

// ** MUI Imports
import Box from '@mui/material/Box'
import Grid from '@mui/material/Grid'
import Alert from '@mui/material/Alert'
import TextField from '@mui/material/TextField'
import AlertTitle from '@mui/material/AlertTitle'
import CardContent from '@mui/material/CardContent'
import PublicIcon from '@mui/icons-material/Public'

// ** Icons Imports
import { useUser } from 'src/utils/context/User/UserProvider'

import { countries, getCountryObject } from 'src/utils/constants'
import { Autocomplete } from '@mui/material'
import ChangeAvatarModal from './components/ChangeAvatarModal'

interface State {
  email: string
  password: string
  showPassword: boolean
  role: string
  fullname: string
  pagename: string
  country: string
  countryObject: CountryType | null
  phone: string
  website: string
  linkedin: string
  twitter: string
  facebook: string
}

const TabAccount = () => {
  // ** State
  const [modalOpen, setModalOpen] = useState<boolean>(false)

  // ** Hook
  const { user } = useUser()

  const [values, setValues] = useState<State>({
    email: '',
    password: '',
    showPassword: false,
    role: '',
    fullname: '',
    pagename: '',
    country: '',
    countryObject: null,
    phone: '',
    website: '',
    linkedin: '',
    twitter: '',
    facebook: ''
  })

  useEffect(() => {
    if (user) {
      const ud = user
      ud['countryObject'] = getCountryObject(ud.country)
      setValues(ud)
    }
  }, [user])

  const handleModalClose = () => setModalOpen(false)

  return (
    <>
      <CardContent>
        <form>
          <Grid container spacing={7} sx={{ pl: 5, pr: 5 }}>
            <Grid item xs={12} sx={{ mb: 5, mt: 5 }}>
              <Alert severity='warning' sx={{ '& a': { fontWeight: 400 } }}>
                <AlertTitle>You can edit your account infomations</AlertTitle>
              </Alert>
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label='Full Name'
                placeholder='John Dae'
                value={values?.fullname}
                onChange={e => setValues({ ...values, fullname: e.target.value })}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label='Page Name'
                disabled
                value={`https://sendmeanote.app/c/${values?.pagename}`}
                onChange={e => setValues({ ...values, pagename: e.target.value })}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label='Phone'
                placeholder='+1 1234567890'
                value={values?.phone}
                onChange={e => setValues({ ...values, phone: e.target.value })}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField fullWidth type='email' label='Email' value={values?.email} disabled />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label='WebSite'
                placeholder='https://abc.com'
                value={values?.website}
                onChange={e => setValues({ ...values, website: e.target.value })}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <Autocomplete
                id='country-select-demo'
                fullWidth
                options={countries}
                autoHighlight
                getOptionLabel={option => option.label}
                renderOption={(props, option) => (
                  <Box component='li' sx={{ '& > img': { mr: 2, flexShrink: 0 } }} {...props}>
                    {option.code === 'WW' ? (
                      <PublicIcon sx={{ marginLeft: -1, marginRight: 2 }} />
                    ) : (
                      <img
                        loading='lazy'
                        width='20'
                        srcSet={`https://flagcdn.com/w40/${option.code.toLowerCase()}.png 2x`}
                        src={`https://flagcdn.com/w20/${option.code.toLowerCase()}.png`}
                        alt=''
                      />
                    )}
                    {option.label} ({option.code})
                  </Box>
                )}
                renderInput={params => (
                  <TextField
                    {...params}
                    label='Choose a country'
                    inputProps={{
                      ...params.inputProps,
                      autoComplete: 'new-password' // disable autocomplete and autofill
                    }}
                  />
                )}
                value={values?.countryObject}
                onChange={(event, newValue: CountryType | null) => {
                  setValues({ ...values, countryObject: newValue, country: newValue?.code ?? '' })
                }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label='Linkedin'
                value={values?.linkedin}
                onChange={e => setValues({ ...values, linkedin: e.target.value })}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label='Twitter'
                value={values?.twitter}
                onChange={e => setValues({ ...values, twitter: e.target.value })}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label='Facebook'
                value={values?.facebook}
                onChange={e => setValues({ ...values, facebook: e.target.value })}
              />
            </Grid>
          </Grid>
        </form>
      </CardContent>
      <ChangeAvatarModal open={modalOpen} onClose={handleModalClose} />
    </>
  )
}

export default TabAccount
