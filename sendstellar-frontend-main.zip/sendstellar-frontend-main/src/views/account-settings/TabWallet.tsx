// ** React Imports
import { useState, ChangeEvent, useEffect } from 'react'

// ** MUI Imports
import Box from '@mui/material/Box'
import Grid from '@mui/material/Grid'
import Alert from '@mui/material/Alert'
import TextField from '@mui/material/TextField'
import Typography from '@mui/material/Typography'
import CardContent from '@mui/material/CardContent'
import Button from '@mui/material/Button'

import { showSnackBar } from 'src/store/slices/snackbar.slice'
import { showBackdrop, hideBackdrop } from 'src/store/slices/backdrop.slice'
import { useAppDispatch } from 'src/store/hooks'
import { useUser } from 'src/utils/context/User/UserProvider'

// Freighter wallet
import { isConnected, requestAccess } from '@stellar/freighter-api'

const API_URL = process.env.NEXT_PUBLIC_API_URL
interface State {
  wallet_address: string
  new_wallet_address: string
}

const TabWallet = () => {
  const dispatch = useAppDispatch()

  // ** State
  const { user, syncUserInfo } = useUser()

  const [values, setValues] = useState<State>({
    wallet_address: '',
    new_wallet_address: ''
  })

  useEffect(() => {
    setValues(user)
  }, [user])

  const handleChange = (prop: keyof State) => (event: ChangeEvent<HTMLInputElement>) => {
    setValues({ ...values, [prop]: event.target.value })
  }

  const handleAutoFillWithConnected = async () => {
    const isAppConnected = await isConnected()

    if (!isAppConnected.isConnected) {
      alert('You have to install Freighter Wallet')

      return
    }

    const accessObj = await requestAccess()

    if (!accessObj.error) {
      setValues(prev => {
        return { ...prev, new_wallet_address: accessObj.address }
      })
    }
  }

  const handleReset = () => {
    setValues(prev => {
      return { ...prev, new_wallet_address: '' }
    })
  }

  const handleSubmit = (e: any) => {
    e.preventDefault()

    const options = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(values)
    }

    dispatch(
      showBackdrop({
        message: `Please wait...`
      })
    )

    fetch(API_URL + '/users/change_my_wallet_address', options)
      .then(response => response.json())
      .then(async data => {
        dispatch(hideBackdrop(null))

        if (data.success) {
          dispatch(showSnackBar({ type: 'success', message: 'Wallet address set successfully.' }))
          await syncUserInfo()
        } else {
          dispatch(showSnackBar({ type: 'error', message: data.msg }))
        }
      })
      .catch(error => {
        console.log(error)
        dispatch(hideBackdrop(null))
        dispatch(showSnackBar({ type: 'error', message: `Error on AJAX call: ${error.toString()}` }))
      })
  }

  return (
    <CardContent>
      <form autoComplete='off' onSubmit={handleSubmit}>
        <Grid container spacing={10} sx={{ p: 5 }}>
          <Grid item xs={12} sm={6}>
            <Grid container spacing={5}>
              <Grid item xs={12}>
                <Box>
                  <Typography variant='body1' sx={{ mb: 2 }}>
                    Current wallet address:
                  </Typography>
                </Box>
                <TextField fullWidth value={values?.wallet_address} disabled />
              </Grid>
              <Grid item xs={12}>
                <Box>
                  <Typography variant='body1' sx={{ mb: 2 }}>
                    New wallet address:
                  </Typography>
                </Box>
                <TextField
                  fullWidth
                  value={values?.new_wallet_address}
                  onChange={handleChange('new_wallet_address')}
                  required
                />
              </Grid>
              <Grid item xs={12} sx={{ mt: 3 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Box>
                    <Button variant='contained' color='info' onClick={handleAutoFillWithConnected}>
                      Connect wallet
                    </Button>
                    <Button variant='outlined' color='secondary' onClick={handleReset} sx={{ ml: 3 }}>
                      Reset
                    </Button>
                  </Box>
                  <Button variant='contained' type='submit'>
                    Save Changes
                  </Button>
                </Box>
              </Grid>
            </Grid>
          </Grid>

          <Grid item xs={12} sm={6}>
            <Alert color='info' icon={false} sx={{ mt: 8 }}>
              <ul>
                <li>
                  To use the sendmeanote.app service and receive XLM, you must first register a Stellar wallet, such as
                  Freighter. All payments will be sent to this wallet address.
                </li>
              </ul>
              <ul>
                <li>For creators, they can receive XLM tokens through this wallet.</li>
              </ul>
              <ul>
                <li>For supporters, they can send a note and XLM tokens to fans and projects.</li>
              </ul>
            </Alert>
          </Grid>
        </Grid>
      </form>
    </CardContent>
  )
}

export default TabWallet
