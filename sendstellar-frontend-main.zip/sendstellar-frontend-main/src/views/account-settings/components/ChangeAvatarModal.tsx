// Mui Imports
import { Box, Button, Dialog, DialogContent, DialogTitle, IconButton, Stack, Typography } from '@mui/material'
import CloseIcon from 'mdi-material-ui/Close'
import { useEffect, useState } from 'react'
import { showSnackBar, hideSnackBar } from 'src/store/slices/snackbar.slice'
import { showBackdrop, hideBackdrop } from 'src/store/slices/backdrop.slice'
import { useAppDispatch } from 'src/store/hooks'
import { useUser } from 'src/utils/context/User/UserProvider'
import { avatar_images } from 'src/utils/constants'
import ImageSelect, { ImageSelectItem } from 'src/views/custom/ImageSelect'

const API_URL = process.env.NEXT_PUBLIC_API_URL

export interface ChangeAvatarModalProps {
  open: boolean
  onClose: () => void
}
const ChangeAvatarModal = ({ open, onClose }: ChangeAvatarModalProps) => {
  const dispatch = useAppDispatch()

  // **State
  const [selectedImage, setSelectedImage] = useState<ImageSelectItem | null>(null)

  // Hook
  const { user, syncUserInfo } = useUser()

  useEffect(() => {
    if (open) {
      // clear when modal closes
      setSelectedImage(null)
    }
  }, [open])

  if (!user) {
    return <></>
  }

  const handleImageSelect = (item: ImageSelectItem) => {
    setSelectedImage(item)
  }

  const onSubmit = async () => {
    try {
      dispatch(hideSnackBar(null)) // hide previous error message

      if (!selectedImage) {
        throw new Error(`Please select new avatar!`)
      }

      dispatch(showBackdrop({ message: `Updating your avatar, please wait...` }))

      const options = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url: selectedImage.src
        })
      }
      const response = await fetch(`${API_URL}/users/change_my_avatar`, options)
      const { success, msg } = await response.json()
      if (!success) {
        throw new Error(msg)
      }

      // Victory !!!
      dispatch(showSnackBar({ type: 'success', message: `Your avatar was successfully changed.` }))
      onClose()
      dispatch(hideBackdrop(null))
      await syncUserInfo() // sync User Info
    } catch (error: any) {
      console.log(error)
      dispatch(hideBackdrop(null))

      return dispatch(showSnackBar({ type: 'error', message: `${error.message || error.toString()}` }))
    }
  }

  return (
    <>
      <Dialog
        open={open}
        onClose={onClose}
        scroll='paper'
        aria-labelledby='modal-title'
        aria-describedby='modal-description'
      >
        <DialogTitle>
          <Stack direction={'row'} alignItems={'center'} justifyContent={'space-between'}>
            <Typography variant='h5'>Choose your new avatar.</Typography>
            <IconButton onClick={onClose}>
              <CloseIcon />
            </IconButton>
          </Stack>
        </DialogTitle>
        <DialogContent dividers>
          <Box>
            <ImageSelect
              images={avatar_images as ImageSelectItem[]}
              selectedImage={selectedImage}
              onImageSelect={handleImageSelect}
            />
          </Box>
          <Box mt={2} textAlign={'center'}>
            <Button variant='contained' onClick={onSubmit}>
              Apply
            </Button>
          </Box>
        </DialogContent>
      </Dialog>
    </>
  )
}

export default ChangeAvatarModal
