import React, { useState, useEffect } from 'react'
import Box from '@mui/material/Box'
import Grid from '@mui/material/Grid'
import Container from '@mui/material/Container'
import Typography from '@mui/material/Typography'
import Fade from '@mui/material/Fade'

const ProcessComponent = ({}) => {
  const [zoomIn, setZoomIn] = useState(false)

  useEffect(() => {
    // Add a 3-second delay before triggering the fade-in effect
    const timer = setTimeout(() => {
      setZoomIn(true)
    }, 2000) // 3 seconds delay

    // Clear the timeout if the component unmounts to avoid memory leaks
    return () => clearTimeout(timer)
  }, [])

  return (
    <Box id='testimonial' sx={{ pb: { xs: 6, md: 10 }, backgroundColor: 'background.paper' }}>
      <Container>
        <Grid
          container
          spacing={5}
          sx={{
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            textAlign: 'center' // Ensure the text is centered
          }}
        >
          <Grid item xs={12} md={12}>
            <Typography
              component='h2'
              sx={{
                position: 'relative',
                fontSize: { xs: 40, md: 72 },
                mt: { xs: 0, md: 7 },
                mb: 4,
                lineHeight: 1,
                fontWeight: 'bold'
              }}
            >
              How the{' '}
              <Fade in={zoomIn} timeout={2000}>
                <Typography
                  component='mark'
                  sx={{
                    position: 'relative',
                    color: 'primary.main',
                    fontSize: 'inherit',
                    fontWeight: 'inherit',
                    backgroundColor: 'unset'
                  }}
                >
                  Process{' '}
                  <Box
                    sx={{
                      position: 'absolute',
                      top: { xs: 20, md: 28 },
                      left: 2,
                      transform: 'rotate(6deg)',
                      '& img': { width: { xs: 130, md: 260 }, height: 'auto' }
                    }}
                  >
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src='/images/landing/headline-curve.svg' alt='Headline curve' />
                  </Box>
                </Typography>
              </Fade>
              <br />
              Works
            </Typography>
            <Typography sx={{ color: 'text.primary', mb: 5, mt: 10, ml: { xs: 0, md: 4 }, fontSize: 22 }}>
              When your walled receives XLM tokens, you can exchange it for fiat via MoneyGram.
              <br />
              <br />
              So you don't have to offramp to a bank or other financial institution.
            </Typography>
          </Grid>
        </Grid>
      </Container>
    </Box>
  )
}

export default ProcessComponent
