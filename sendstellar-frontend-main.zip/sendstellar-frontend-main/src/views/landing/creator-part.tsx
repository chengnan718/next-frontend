import React, { ReactNode, FC, useState, useEffect } from 'react'
import Image from 'next/image'
import Box from '@mui/material/Box'
import Grid from '@mui/material/Grid'
import Container from '@mui/material/Container'
import Typography from '@mui/material/Typography'
import Button from '@mui/material/Button'
import Fade from '@mui/material/Fade'
import { useUser } from 'src/utils/context/User/UserProvider'
import { useAppDispatch } from 'src/store/hooks'
import { showSnackBar } from 'src/store/slices/snackbar.slice'

interface Data {
  title: string
  description: string
  icon?: ReactNode
}

interface Exp {
  label: string
  value: string
}
interface ExpItemProps {
  item: Exp
}

const data: Data[] = [
  {
    title: 'Easy Accessable',
    description: 'you are actively engaged with your supporters through a dialogue'
  },
  {
    title: 'More Affordable Cost',
    description: 'supporters feel acknowledged'
  },
  {
    title: 'Flexible Study Time',
    description: 'you can get feedback and potential ideas'
  }
]

const exps: Array<Exp> = [
  {
    label: 'Creators',
    value: '256'
  },
  {
    label: 'Supportors',
    value: '989'
  },
  {
    label: 'XLMs',
    value: '100K+'
  }
]

const ExpItem: FC<ExpItemProps> = ({ item }) => {
  const { value, label } = item

  return (
    <Box sx={{ textAlign: 'center', mb: { xs: 1, md: 0 } }}>
      <Typography
        sx={{ color: 'primary.main', mb: { xs: 1, md: 2 }, fontSize: { xs: 34, md: 44 }, fontWeight: 'bold' }}
      >
        {value}
      </Typography>
      <Typography color='text.primary' variant='h5'>
        {label}
      </Typography>
    </Box>
  )
}

const CreatorComponent = ({}) => {
  const [zoomIn, setZoomIn] = useState(false)
  const { user } = useUser()
  const dispatch = useAppDispatch()

  useEffect(() => {
    setZoomIn(true)
  }, [])

  const viewPublishPage = () => {
    if (user && !user.wallet_address) {
      dispatch(showSnackBar({ type: 'error', message: `You have to register your wallet address` }))

      return
    }

    // Open the URL in a new tab
    window.open('/c/' + user?.pagename, '_blank', 'noopener,noreferrer')
  }

  return (
    <Box id='feature' sx={{ py: { xs: 10, md: 12 }, backgroundColor: 'background.paper' }}>
      <Container sx={{ mt: -9 }}>
        <Grid container spacing={3}>
          <Grid item xs={12} md={7}>
            <Typography
              component='h2'
              sx={{
                position: 'relative',
                fontSize: { xs: 40, md: 70 },
                ml: { xs: 0, md: 4 },
                mt: 2,
                mb: 3,
                lineHeight: 1,
                fontWeight: 'bold'
              }}
            >
              If you're a{' '}
              <Fade in={zoomIn} timeout={1500}>
                <Typography
                  component='mark'
                  sx={{
                    position: 'relative',
                    color: 'primary.main',
                    fontSize: 'inherit',
                    fontWeight: 'inherit',
                    backgroundColor: 'unset'
                  }}
                >
                  Creator <br />
                  <Box
                    sx={{
                      position: 'absolute',
                      top: { xs: 20, md: 28 },
                      transform: 'rotate(3deg)',
                      left: 2,
                      '& img': { width: { xs: 140, md: 240 }, height: 'auto' }
                    }}
                  >
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src='/images/landing/headline-curve.svg' alt='Headline curve' />
                  </Box>
                </Typography>
              </Fade>
            </Typography>

            <Typography sx={{ color: 'text.primary', mb: 5, mt: 5, ml: { xs: 0, md: 4 }, fontSize: 22 }}>
              Supporters of your project can now send you XLM tokens along with a personal note or message. When you
              reply to the note, your crypto wallet receives the XLM tokens. Simple!
            </Typography>

            <Typography sx={{ color: 'text.primary', mb: 5, mt: 5, ml: { xs: 0, md: 4 }, fontSize: 22 }}>
              Then as an option, you can exchange XLM tokens for fiat through Moneygram. So no banking required.
            </Typography>

            <Typography sx={{ color: 'text.primary', mb: 5, mt: 10, ml: { xs: 0, md: 4 }, fontSize: 22 }}>
              Some of the benefits of Send Me A Note:{' '}
            </Typography>
          </Grid>
          <Grid item md={1}></Grid>
          <Grid item xs={12} md={4}>
            <Box sx={{ position: 'relative', mt: -5, ml: -7 }}>
              <Image src='/images/landing/home-hero.jpg' width={400} height={420} quality={97} alt='Feature img' />
            </Box>
          </Grid>
        </Grid>
        <Grid container spacing={4} sx={{ ml: { xs: 0, md: 2 }, width: '97%', mt: 0 }}>
          {data.map(({ description }, index) => (
            <Grid key={String(index)} item xs={12} md={4}>
              <Box sx={{ px: 2, py: 1.5, boxShadow: 2, borderRadius: 2, display: 'flex', alignItems: 'center' }}>
                <Box
                  sx={{
                    mr: 1,
                    ml: 1,
                    backgroundColor: 'primary.main',
                    borderRadius: '50%',
                    height: 36,
                    width: 36,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: 'primary.contrastText',
                    '& svg': {
                      fontSize: 20
                    }
                  }}
                >
                  {index + 1}
                </Box>
                <Box
                  sx={{
                    display: 'flex',
                    flex: 1,
                    flexDirection: 'column',
                    ml: 2,
                    height: 50,
                    justifyContent: 'center'
                  }}
                >
                  <Typography sx={{ lineHeight: 1.3, color: 'text.secondary' }} variant='body1'>
                    {description}
                  </Typography>
                </Box>
              </Box>
            </Grid>
          ))}
        </Grid>
        <Box sx={{ boxShadow: 2, py: 3, px: 6, borderRadius: 4, margin: 6, mt: 10 }}>
          <Grid container spacing={2}>
            {exps.map(item => (
              <Grid key={item.value} item xs={12} md={4}>
                <ExpItem item={item} />
              </Grid>
            ))}
          </Grid>
        </Box>
        <Box
          sx={{
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center'
          }}
        >
          <Button
            variant='contained'
            color='error'
            sx={{
              fontSize: { xs: '16px', md: '20px' },
              padding: { xs: '10px 16px', md: '14px 22px' }, // Tripled padding
              fontWeight: 'bold',
              borderRadius: '8px',
              textTransform: 'none',
              mt: 5,
              boxShadow: 3,
              ':hover': {
                boxShadow: 6,
                backgroundColor: 'primary.dark'
              }
            }}
            onClick={viewPublishPage}
          >
            View My Page
          </Button>
        </Box>
      </Container>
    </Box>
  )
}

export default CreatorComponent
