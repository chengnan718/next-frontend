import React, { FC, useState, useEffect } from 'react'
import Box from '@mui/material/Box'
import Grid from '@mui/material/Grid'
import Container from '@mui/material/Container'
import Typography from '@mui/material/Typography'
import Image from 'next/image'
import Fade from '@mui/material/Fade'

const SupportComponent: FC = () => {
  const [zoomIn, setZoomIn] = useState(false)

  useEffect(() => {
    // Add a 3-second delay before triggering the fade-in effect
    const timer = setTimeout(() => {
      setZoomIn(true)
    }, 1200) // 3 seconds delay

    // Clear the timeout if the component unmounts to avoid memory leaks
    return () => clearTimeout(timer)
  }, [])

  return (
    <Box
      id='popular-course'
      sx={{
        mt: -3,
        pt: { xs: 10, md: 16 },
        pb: 14,
        backgroundColor: '#e5fcef',
        marginLeft: -6,
        marginRight: -6
      }}
    >
      <Container maxWidth='lg'>
        <Grid container spacing={2}>
          <Grid item xs={12} md={5} sx={{ position: 'relative' }}>
            <Box sx={{ lineHeight: 0, marginTop: 1, marginLeft: 7 }}>
              <Image src='/images/landing/home-feature.png' width={340} height={350} alt='Hero img' />
            </Box>
          </Grid>
          <Grid item xs={12} md={7}>
            <Box
              sx={{
                textAlign: { xs: 'center', md: 'left' },
                height: '100%',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'center'
              }}
            >
              <Box sx={{ mb: 3 }}>
                <Typography
                  component='h2'
                  sx={{
                    position: 'relative',
                    fontSize: { xs: 40, md: 72 },
                    letterSpacing: 1.5,
                    fontWeight: 'bold',
                    lineHeight: 1.3
                  }}
                >
                  If you&nbsp;
                  <Fade in={zoomIn} timeout={2000}>
                    <Typography
                      component='mark'
                      sx={{
                        position: 'relative',
                        color: 'primary.main',
                        fontSize: 'inherit',
                        fontWeight: 'inherit',
                        backgroundColor: 'unset'
                      }}
                    >
                      Support{' '}
                      <Box
                        sx={{
                          position: 'absolute',
                          top: { xs: 24, md: 34 },
                          left: 2,
                          transform: 'rotate(5deg)',
                          '& img': { width: { xs: 146, md: 280 }, height: 'auto' }
                        }}
                      >
                        {/* eslint-disable-next-line */}
                        <img src='/images/landing/headline-curve.svg' alt='Headline curve' />
                      </Box>
                    </Typography>
                  </Fade>
                  <Typography
                    component='span'
                    sx={{
                      fontSize: 'inherit',
                      fontWeight: 'inherit',
                      position: 'relative',
                      '& svg': {
                        position: 'absolute',
                        top: -16,
                        right: -21,
                        width: { xs: 22, md: 30 },
                        height: 'auto'
                      }
                    }}
                  >
                    <svg version='1.1' viewBox='0 0 3183 3072'>
                      <g id='Layer_x0020_1'>
                        <path
                          fill='#127C71'
                          d='M2600 224c0,0 0,0 0,0 236,198 259,562 52,809 -254,303 -1849,2089 -2221,1776 -301,-190 917,-1964 1363,-2496 207,-247 570,-287 806,-89z'
                        />
                        <path
                          fill='#127C71'
                          d='M3166 2190c0,0 0,0 0,0 64,210 -58,443 -270,516 -260,90 -1848,585 -1948,252 -104,-230 1262,-860 1718,-1018 212,-73 437,39 500,250z'
                        />
                        <path
                          fill='#127C71'
                          d='M566 3c0,0 0,0 0,0 -219,-26 -427,134 -462,356 -44,271 -255,1921 90,1962 245,62 628,-1392 704,-1869 36,-221 -114,-424 -332,-449z'
                        />
                      </g>
                    </svg>
                  </Typography>
                  <br />
                  creators
                </Typography>
              </Box>
              <Box sx={{ mb: 4, width: { xs: '100%', md: '70%' } }}>
                <Typography sx={{ color: 'text.primary', lineHeight: 1.6, fontSize: 22 }}>
                  {
                    "Fund your favorite creator or project by sending a personal note and XLM tokens. If you don't receive a reply within 72 hours, simply reclaim your tokens with a single click."
                  }
                </Typography>
              </Box>
            </Box>
          </Grid>
        </Grid>
      </Container>
    </Box>
  )
}

export default SupportComponent
