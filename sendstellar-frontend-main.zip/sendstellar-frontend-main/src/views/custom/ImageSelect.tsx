import React from 'react';
import { Grid, Card, CardMedia, CardActionArea, Typography } from '@mui/material';

export interface ImageSelectItem {
  id: number;
  title: string;
  src: string;
}

interface ImageSelectProps {
  images: ImageSelectItem[];
  selectedImage: ImageSelectItem | null;
  onImageSelect: (item: ImageSelectItem) => void;
}

const ImageSelect: React.FC<ImageSelectProps> = ({ images, selectedImage, onImageSelect }) => {
  return (
    <Grid container spacing={2}>
      {images.map((image) => (
        <Grid item xs={4} sm={4} md={3} key={image.id}>
          <Card
            onClick={() => onImageSelect(image)}
            sx={{
              border: selectedImage?.id === image.id ? '2px solid blue' : 'none',
            }}
          >
            <CardActionArea>
              <CardMedia
                component="img"
                height="150"
                image={image.src}
                alt={image.title}
              />
              <Typography variant="body2" color="textSecondary" component="div" align="center">
                {image.title}
              </Typography>
            </CardActionArea>
          </Card>
        </Grid>
      ))}
    </Grid>
  );
};

export default ImageSelect;
