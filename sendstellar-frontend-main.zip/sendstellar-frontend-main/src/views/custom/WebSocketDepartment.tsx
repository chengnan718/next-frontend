import { useEffect } from 'react'
import { setOnlineStatus } from 'src/store/slices/main.slice'
import { useAppDispatch } from 'src/store/hooks'
import { useUser } from 'src/utils/context/User/UserProvider'

const WebSocketDepartment = () => {
  const dispatch = useAppDispatch()
  const { user } = useUser()

  useEffect(() => {
    const userId = user?.id // Example user ID, you should dynamically set this for each user
    if (!userId) {
      return
    }
    const ws = new WebSocket(`ws://localhost:3001/?userId=${userId}`)

    ws.onmessage = event => {
      try {
        const message = JSON.parse(event.data)
        if (message.type === 'userStatus') {
          dispatch(setOnlineStatus(message.data))
        }
      } catch (e) {
        console.error(e)
      }
    }

    return () => {
      ws.close()
    }
  }, [user, dispatch])

  return <></>
}

export default WebSocketDepartment
