import { styled } from '@mui/material/styles'
import { Box, CardContent, FormControl } from '@mui/material'

export const CustomCardContent = styled(CardContent)(({ theme }) => ({
  marginLeft: theme.spacing(2),
  marginRight: theme.spacing(2)
}))

export const CustomCardHeader = styled(Box)(({ theme }) => ({
  display: 'flex',
  justifyContent: 'flex-start',
  alignItems: 'center',
  gap: theme.spacing(3),
  marginBottom: theme.spacing(5),
  '& .cardheader-icon': {
    color: theme.palette.mode === 'light' ? theme.palette.text.primary : theme.palette.success.main
  },
  '& .cardheader-title': {
    color: theme.palette.mode === 'light' ? theme.palette.text.primary : theme.palette.customColors.semiwhite
  }
}))

/**
 * Warning: MUI 's InputLabel is not working in styled(FormControl)
 * It 's weired
 * Hence, if you wanna to customize FormContrl for above case.
 * Please use MyFormControlWrapper = styled(Box)
 */
export const CustomFormControl = styled(FormControl)(({ theme }) => ({
  marginBottom: theme.spacing(7),
  '& .control-title': {
    color: theme.palette.secondary.main,
    fontWeight: 700,
    marginBottom: theme.spacing(2)
  },
  '& .control-element': {
    marginBottom: theme.spacing(2)
  },
  '& .control-element .MuiOutlinedInput-input': {
    color: theme.palette.mode === 'light' ? theme.palette.text.primary : theme.palette.customColors.semiwhite, // style for inputed text
    paddingTop: '12px',
    paddingBottom: '12px',
    borderWidth: '5px'
  },
  '& .control-element .MuiAutocomplete-inputRoot': {
    paddingTop: '0px',
    paddingBottom: '0px'
  },
  '& .control-element .MuiAutocomplete-input': {
    paddingTop: '12px!important',
    paddingBottom: '12px!important'
  },
  '& .control-element fieldset': {
    borderWidth: '2px',
    borderColor: '#777E90'
  },
  '& .control-help': {
    margin: 0
  },
  '& .control-switch-title': {
    color: theme.palette.mode === 'light' ? theme.palette.text.primary : theme.palette.customColors.semiwhite
  }
}))
