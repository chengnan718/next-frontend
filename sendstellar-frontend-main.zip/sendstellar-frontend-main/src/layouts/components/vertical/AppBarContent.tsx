// ** Next Imports
import Link from 'next/link'
import Box from '@mui/material/Box'
import { Theme, styled } from '@mui/material/styles'
import TextField from '@mui/material/TextField'
import IconButton from '@mui/material/IconButton'
import useMediaQuery from '@mui/material/useMediaQuery'
import InputAdornment from '@mui/material/InputAdornment'

// ** Icons Imports
import Menu from 'mdi-material-ui/Menu'
import Magnify from 'mdi-material-ui/Magnify'

// ** Type Import
import { Settings } from 'src/@core/context/settingsContext'

// ** Components
import UserDropdown from 'src/@core/layouts/components/shared-components/UserDropdown'
import { Button, Stack, Typography } from '@mui/material'
import { useEffect, useState } from 'react'
import { useUser } from 'src/utils/context/User/UserProvider'
import { useRouter } from 'next/router'

interface Props {
  hidden: boolean
  settings: Settings
  toggleNavVisibility: () => void
  saveSettings: (values: Settings) => void
}

const LogoImg = styled('img')({
  height: 80,
  marginBottom: 0,
  marginLeft: 2,
  paddingLeft: 240,
  paddingRight: 160,
  marginTop: 17
})

const TopMenuItem = styled(Typography)({
  cursor: 'pointer',
  minWidth: 100,
  textDecoration: 'unset',
  paddingLeft: 3,
  paddingRight: 3,
  '&:hover': {
    // color: 'red',
    color: 'blue'
  }
})

const AppBarContent = (props: Props) => {
  // ** Props
  const { hidden, toggleNavVisibility } = props

  // ** Hook
  const hiddenSm = useMediaQuery((theme: Theme) => theme.breakpoints.down('sm'))

  const { user } = useUser()
  const [globalSearchWord, setGlobalSearchWord] = useState<string>('')

  // Mobile state for tooltip
  const [openTooltip, setOpenTooltip] = useState(false)

  // Active button state
  const [activeButton, setActiveButton] = useState<string>('')

  // Reset activeButton when the page loads
  const router = useRouter()

  useEffect(() => {
    if (router.pathname === '/pages/login') {
      setActiveButton('login')
    } else if (router.pathname === '/pages/register') {
      setActiveButton('signup')
    } else {
      setActiveButton('')
    }
  }, [router.pathname])

  useEffect(() => {
    if (hiddenSm) {
      const timer = setTimeout(() => setOpenTooltip(false), 2000) // Auto-close after 2 seconds

      return () => clearTimeout(timer)
    }
  }, [openTooltip, hiddenSm])

  return (
    <Box sx={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
      <Box className='actions-left' sx={{ display: 'flex', alignItems: 'center' }}>
        {hidden ? (
          <IconButton
            color='inherit'
            onClick={toggleNavVisibility}
            sx={{ ml: -2.75, ...(hiddenSm ? {} : { mr: 3.5 }) }}
          >
            <Menu />
          </IconButton>
        ) : null}
      </Box>
      <Box
        className='actions-right'
        sx={{ display: 'flex', alignItems: 'center', marginBottom: '-15px', flexGrow: 1, justifyContent: 'center' }}
      >
        {!hidden && (
          <Stack direction={'row'} alignItems={'center'} spacing={3}>
            <TextField
              size='small'
              sx={{ '& .MuiOutlinedInput-root': { borderRadius: 4 } }}
              placeholder='Search creators'
              InputProps={{
                startAdornment: (
                  <InputAdornment position='start'>
                    <Magnify fontSize='small' />
                  </InputAdornment>
                )
              }}
              value={globalSearchWord}
              onChange={event => {
                setGlobalSearchWord(event.target.value)
              }}
              onKeyDown={event => {
                if (event.key === 'Enter') {
                  location.href = `/experts?name=${globalSearchWord}`
                }
              }}
            />
            <Link passHref href={`/`} style={{ display: 'inline-block' }}>
              <LogoImg className={`cursorPoint`} alt='Home' src='/images/logos/logo.webp' />
            </Link>
            <Link passHref href={`/pages/faq`} prefetch={false}>
              <TopMenuItem style={{ minWidth: '0px', marginRight: 20, color: 'black' }}>FAQs</TopMenuItem>
            </Link>
            {user ? (
              <>
                <Link passHref href={`/dashboard/supporter/`} prefetch={false}>
                  <TopMenuItem style={{ minWidth: '0px', marginRight: 20, color: 'black' }}>Supporters</TopMenuItem>
                </Link>
                <UserDropdown />
              </>
            ) : (
              <>
                <Link passHref href='/pages/login'>
                  <Button
                    variant='outlined'
                    color='secondary'
                    sx={{
                      color: 'black',
                      backgroundColor: activeButton === 'login' ? '#e5ebfa' : 'transparent',
                      borderRadius: 40,
                      border: 'none'
                    }}
                    onClick={() => setActiveButton('login')}
                  >
                    Log in
                  </Button>
                </Link>
                <Link passHref href='/pages/register'>
                  <Button
                    variant='outlined'
                    color='secondary'
                    sx={{
                      color: 'black',
                      backgroundColor: activeButton === 'signup' ? '#e5ebfa' : 'transparent',
                      borderRadius: 40,
                      border: 'none'
                    }}
                    onClick={() => setActiveButton('signup')}
                  >
                    Sign Up
                  </Button>
                </Link>
              </>
            )}
          </Stack>
        )}
      </Box>
    </Box>
  )
}

export default AppBarContent
