import { Box } from '@mui/material'
import Alert from '@mui/material/Alert'
import Link from 'next/link'
import { useUser } from 'src/utils/context/User/UserProvider'

const UserWarningBlock = () => {
  const { user, sendVerificationEmail } = useUser()

  const UnsetWalletWarning = user && !user.wallet_address && (
    <Alert severity='error' sx={{ color: 'black' }}>
      You need to register your crypto wallet to start using sendmeanote.app. Please register
      <Link
        href={'https://www.freighter.app/'}
        target='_blank'
        style={{ textDecoration: 'underline', color: 'saddlebrown' }}
      >
        {' '}
        freighter{' '}
      </Link>{' '}
      wallet in our{' '}
      <Link href={'/account-settings'} style={{ textDecoration: 'underline', color: 'saddlebrown' }}>
        {' '}
        profile page{' '}
      </Link>{' '}
      under the heading WALLET.
    </Alert>
  )

  const EmailVerifyWarning = user && !user.is_email_verified && (
    <Alert severity='error' sx={{ mb: 4, mt: 2, color: 'black' }}>
      Please verify your email address{' '}
      <Link
        href={'#'}
        onClick={() => {
          sendVerificationEmail()
        }}
        style={{ textDecoration: 'underline', color: 'saddlebrown' }}
      >
        here
      </Link>{' '}
      to use the Asked.app.
    </Alert>
  )

  return (
    <>
      <Box
        sx={{
          mx: '1px', // Centers the Box horizontally
          mb: 3,
          pl: 3,
          flexDirection: 'column',
          alignItems: 'center', // Optional: Centers items inside the Box horizontally
          justifyContent: 'center' // Optional: Centers items inside the Box vertically
        }}
      >
        {UnsetWalletWarning}
        {EmailVerifyWarning}
      </Box>
    </>
  )
}

export default UserWarningBlock
