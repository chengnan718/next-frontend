import { PayloadAction, createSlice } from '@reduxjs/toolkit'

export type MainSliceState = {
  onlineStatus: Dict<boolean>
  taskStore: Array<any>
}

const initialState: MainSliceState = {
  // primary
  onlineStatus: {},
  taskStore: []
}

const mainSlice = createSlice({
  name: 'main',
  initialState,
  reducers: {
    // primary
    setOnlineStatus(state, action: PayloadAction<Dict<boolean>>) {
      const onlineStatus: Dict<boolean> = action.payload ?? {}
      state.onlineStatus = onlineStatus
    },
    setTaskStore(state, action: PayloadAction<Array<any>>) {
      const tasks: Array<any> = action.payload
      state.taskStore = tasks
    }
  }
})

export const {
  // primary
  setOnlineStatus,
  setTaskStore
} = mainSlice.actions

export default mainSlice.reducer
