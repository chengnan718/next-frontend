// ** MUI Imports
import Grid from '@mui/material/Grid'

// ** Styled Component Import
import ApexChartWrapper from 'src/@core/styles/libs/react-apexcharts'

// ** Add Custom Component
import CreatorComponent from 'src/views/landing/creator-part'
import SupportComponent from 'src/views/landing/support-part'
import ProcessComponent from 'src/views/landing/process-part'

const LandingPage = () => {
  return (
    <ApexChartWrapper>
      <Grid container spacing={6}>
        <Grid item xs={12}>
          <CreatorComponent />
        </Grid>
        <Grid item xs={12}>
          <SupportComponent />
        </Grid>
        <Grid item xs={12}>
          <ProcessComponent />
        </Grid>
      </Grid>
    </ApexChartWrapper>
  )
}

export default LandingPage
