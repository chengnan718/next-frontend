// ** MUI Imports
import { useUser } from 'src/utils/context/User/UserProvider'
import DashboardLayout from '../layout'
import SettingComponent from 'src/views/dashboard/settings/setting'

const DashboardSetting = () => {
  const { user } = useUser()

  if (!user) {
    return <></> // This is important. In Next.js, localstorage is loaded little late.
  }

  return (
    <DashboardLayout>
      <SettingComponent />
    </DashboardLayout>
  )
}

export default DashboardSetting
