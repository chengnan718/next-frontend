// ** MUI Imports
import { useUser } from 'src/utils/context/User/UserProvider'
import DashboardContent from 'src/views/dashboard/content'
import DashboardLayout from './layout'

const Dashboard = () => {
  const { user } = useUser()

  if (!user) {
    return <></> // This is important. In Next.js, localstorage is loaded little late.
  }

  return (
    <DashboardLayout>
      <DashboardContent />
    </DashboardLayout>
  )
}

export default Dashboard
