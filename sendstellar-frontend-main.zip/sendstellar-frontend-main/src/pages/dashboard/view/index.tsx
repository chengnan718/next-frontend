// ** MUI Imports
import { useUser } from 'src/utils/context/User/UserProvider'
import DashboardLayout from '../layout'
import PageViewComponent from 'src/views/dashboard/view/view'

const DashboardView = () => {
  const { user } = useUser()

  if (!user) {
    return <></> // This is important. In Next.js, localstorage is loaded little late.
  }

  return (
    <DashboardLayout>
      <PageViewComponent />
    </DashboardLayout>
  )
}

export default DashboardView
