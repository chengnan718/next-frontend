// ** MUI Imports
import { useUser } from 'src/utils/context/User/UserProvider'
import DashboardLayout from '../layout'
import CreatorSupporterComponent from 'src/views/dashboard/supporter/suppoter'

const DashboardSupporter = () => {
  const { user } = useUser()

  if (!user) {
    return <></> // This is important. In Next.js, localstorage is loaded little late.
  }

  return (
    <DashboardLayout>
      <CreatorSupporterComponent />
    </DashboardLayout>
  )
}

export default DashboardSupporter
