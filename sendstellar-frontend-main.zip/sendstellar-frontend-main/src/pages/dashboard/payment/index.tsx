// ** MUI Imports
import { useUser } from 'src/utils/context/User/UserProvider'
import DashboardLayout from '../layout'
import PaymentComponent from 'src/views/dashboard/payment/payment'

const DashboardPayment = () => {
  const { user } = useUser()

  if (!user) {
    return <></> // This is important. In Next.js, localstorage is loaded little late.
  }

  return (
    <DashboardLayout>
      <PaymentComponent />
    </DashboardLayout>
  )
}

export default DashboardPayment
