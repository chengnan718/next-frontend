// ** MUI Imports
import { useUser } from 'src/utils/context/User/UserProvider'
import DashboardLayout from '../layout'
import AnswerNoteComponent from 'src/views/dashboard/answer/answer'

const DashboardAnswer = () => {
  const { user } = useUser()

  if (!user) {
    return <></> // This is important. In Next.js, localstorage is loaded little late.
  }

  return (
    <DashboardLayout>
      <AnswerNoteComponent />
    </DashboardLayout>
  )
}

export default DashboardAnswer
