// ** MUI Imports
import { Box, Grid } from '@mui/material'
import React, { ReactNode } from 'react'
import { useUser } from 'src/utils/context/User/UserProvider'
import DashboardSidebar from 'src/views/dashboard/sidebar'

// Define the prop types for the component
interface DashboardLayoutProps {
  children: ReactNode // This ensures children can be any valid React nodes
}

const DashboardLayout: React.FC<DashboardLayoutProps> = ({ children }) => {
  const { user } = useUser()

  if (!user) {
    return <></> // This is important. In Next.js, localstorage is loaded little late.
  }

  return (
    <>
      <Grid container sx={{ flex: 1, margin: '0 auto', maxWidth: 'calc(1440px - 1.5rem * 2)' }} spacing={5}>
        <Grid item xs={12} md={3}>
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'center', // Centers the first Box horizontally
              flex: 1,
              backgroundColor: 'background.paper',
              boxShadow: 2,
              borderRadius: 2,
              ml: -2
            }}
          >
            <Box
              sx={{
                display: 'flex',
                justifyContent: 'center', // Centers the second Box horizontally
                flex: '1',
                mt: 5,
                mb: 5,
                p: 5
              }}
            >
              <DashboardSidebar />
            </Box>
          </Box>
        </Grid>
        <Grid item xs={12} md={9}>
          {children}
        </Grid>
      </Grid>
    </>
  )
}

export default DashboardLayout
