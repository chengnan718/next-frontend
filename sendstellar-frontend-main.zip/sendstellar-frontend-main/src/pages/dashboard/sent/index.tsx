// ** MUI Imports
import { useUser } from 'src/utils/context/User/UserProvider'
import DashboardLayout from '../layout'
import SentNoteComponent from 'src/views/dashboard/sent/sent'

const DashboardSentPage = () => {
  const { user } = useUser()

  if (!user) {
    return <></> // This is important. In Next.js, localstorage is loaded little late.
  }

  return (
    <DashboardLayout>
      <SentNoteComponent />
    </DashboardLayout>
  )
}

export default DashboardSentPage
