// ** MUI Imports
import { useUser } from 'src/utils/context/User/UserProvider'
import DashboardLayout from '../layout'
import PageEditComponent from 'src/views/dashboard/edit/edit'

const DashboardEdit = () => {
  const { user } = useUser()

  if (!user) {
    return <></> // This is important. In Next.js, localstorage is loaded little late.
  }

  return (
    <DashboardLayout>
      <PageEditComponent />
    </DashboardLayout>
  )
}

export default DashboardEdit
