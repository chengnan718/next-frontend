// pages/[username].tsx
import { GetServerSideProps } from 'next/types'
import React, { useState } from 'react'
import {
  Box,
  Grid,
  Card,
  CardMedia,
  CardContent,
  Avatar,
  CardHeader,
  Typography,
  IconButton,
  CardActions,
  Divider,
  List,
  ListItem,
  ListItemAvatar,
  Button,
  TextField,
  FormControlLabel,
  Checkbox
} from '@mui/material'
import FavoriteIcon from '@mui/icons-material/Favorite'
import ShareIcon from '@mui/icons-material/Share'
import MoreVertIcon from '@mui/icons-material/MoreVert'

import { useUser } from 'src/utils/context/User/UserProvider'
import { showSnackBar } from 'src/store/slices/snackbar.slice'
import { showBackdrop, hideBackdrop } from 'src/store/slices/backdrop.slice'
import { useAppDispatch } from 'src/store/hooks'
import { useRouter } from 'next/router'

import { useWeb3 } from 'src/utils/context/Web3/web3Context'

const API_URL = process.env.NEXT_PUBLIC_API_URL

interface UserData {
  intro: string
  head: string
  image2: string
  user_id: string
  wallet_address: string
}

interface Props {
  pageData: {
    pagename: string
    userData: UserData
  }
}

interface PageState {
  count: number
  name: string | null
  note: string | null
  is_private: boolean
  sender: string
  receiver: string
  sender_wallet: string
  receiver_wallet: string
  balanceId: string
}

const colorGroup = {
  background: '#f0f0f0',
  selected: '#127c71',
  unselected: '#8da29f'
}

const items = [
  { title: 'Introduction', type: 'Photos', date: 'Jan 9, 2014' },
  { title: 'Introduction', type: 'Photos', date: 'Jan 9, 2014' },
  { title: 'Introduction', type: 'Photos', date: 'Jan 9, 2014' }
]

const initialFormValues: PageState = {
  count: 10,
  name: '',
  note: '',
  is_private: false,
  sender: '',
  receiver: '',
  sender_wallet: '',
  receiver_wallet: '',
  balanceId: ''
}

const UserPage = ({ pageData }: Props) => {
  const { user } = useUser()
  const dispatch = useAppDispatch()
  const router = useRouter()

  const [selectedAvatar, setSelectedAvatar] = useState<number>(10)

  const [formValues, setFormValues] = useState<PageState>(initialFormValues)

  const [formErrors, setFormErrors] = useState({
    count: '',
    name: '',
    note: '',
    is_private: false
  })

  const handleInputChange = (event: any) => {
    const { name, value } = event.target
    setFormValues(prevValues => ({
      ...prevValues,
      [name]: value
    }))
  }

  const { connectState, retrievePublicKey, sendXLMClaimableCondition } = useWeb3()

  const handleAvatarClick = (value: number) => {
    setSelectedAvatar(value)
    setFormValues(prevValues => ({
      ...prevValues,
      count: value
    }))
  }

  const handleCheckboxChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setFormValues(prevValues => ({
      ...prevValues,
      is_private: event.target.checked
    }))
  }

  const validate = () => {
    const errors: any = {}
    if (formValues.count <= 0) {
      errors.count = 'XLM amount needs to be greater 0'
    }
    if (formValues.note === '') {
      errors.note = 'Input some notes to creators'
    }
    setFormErrors(errors)

    return Object.keys(errors).length === 0
  }

  const handleSubmit = async (event: any) => {
    event.preventDefault()

    // Check to send to yourself
    if (user?.pagename === pageData.pagename) {
      dispatch(showSnackBar({ type: 'error', message: `You can't Send A Note to yourself` }))

      return
    }

    // Check logged in
    if (!user) {
      router.push('/pages/login')
    }

    // Send XLM and Note to your fan or project
    // Step 1. Wallet Connect Status Check
    const isConnected = await connectState()

    if (!isConnected) {
      dispatch(showSnackBar({ type: 'error', message: `Please install and connect your wallet` }))

      return
    }

    // Step 2. XLM and Note Check
    if (!validate()) return

    const newFormValues = { ...formValues }
    newFormValues.sender = user?.id
    newFormValues.receiver = pageData.userData.user_id

    // Step 3. Check the Wallet Address
    const myAddress = await retrievePublicKey()
    const toAddress = pageData.userData.wallet_address

    newFormValues.sender_wallet = myAddress
    newFormValues.receiver_wallet = toAddress

    dispatch(
      showBackdrop({
        message: `Please wait for transaction ...`
      })
    )

    const sendResult = await sendXLMClaimableCondition(myAddress, toAddress, newFormValues.count.toString())

    if (sendResult) {
      dispatch(hideBackdrop(null))
      dispatch(showSnackBar({ type: 'success', message: `Successfully ${newFormValues.count} XLM Sent With a Note` }))
      setFormValues(initialFormValues)
      handleAvatarClick(10)

      newFormValues.balanceId = sendResult

      const response = await fetch(`${API_URL}/notes/add`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(newFormValues)
      })

      const data = await response.json()
      if (data.success) {
        dispatch(hideBackdrop(null))
        console.log('Successfully added')
      } else {
        dispatch(hideBackdrop(null))
        console.error('Form submission failed')
      }
    } else {
      dispatch(hideBackdrop(null))
      dispatch(showSnackBar({ type: 'error', message: `Failed to Send. Try again.` }))
    }
  }

  return (
    <Box
      sx={{
        display: 'flex',
        justifyContent: 'center',
        flex: 1,
        margin: '0 auto',
        maxWidth: '1140px'
      }}
    >
      <Grid container sx={{ flex: 1 }} spacing={5}>
        <Grid item xs={12} md={6}>
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'center',
              flex: 1,
              backgroundColor: 'background.paper',
              boxShadow: 2,
              borderRadius: 2
            }}
          >
            <Card sx={{ p: 4, borderRadius: 2 }}>
              <CardHeader
                avatar={<Avatar aria-label='recipe'>{pageData.pagename.charAt(0).toUpperCase()}</Avatar>}
                action={
                  <IconButton aria-label='settings'>
                    <MoreVertIcon />
                  </IconButton>
                }
                title={pageData.pagename}
                subheader={pageData.userData.head}
                sx={{ mt: -3 }}
              />
              <CardMedia
                component='img'
                height='200'
                image={
                  pageData?.userData?.image2
                    ? `http://sendmeanote.app/api/uploads/pages/${pageData.userData.image2}`
                    : '/images/cards/glass-house.png'
                }
                alt='Paella dish'
                sx={{ borderRadius: 2, ml: 4, mt: 3, width: '93%' }}
              />
              <CardContent>
                <Typography variant='h5'>About {pageData.pagename}</Typography>
                <Typography variant='body1' sx={{ color: 'text.secondary', mt: 3 }}>
                  {pageData.userData.intro}
                </Typography>
              </CardContent>
              <CardActions disableSpacing>
                <IconButton aria-label='add to favorites'>
                  <FavoriteIcon />
                </IconButton>
                <IconButton aria-label='share'>
                  <ShareIcon />
                </IconButton>
              </CardActions>
              <Divider></Divider>
              <CardContent>
                <Typography variant='h5'>Recent Supporters</Typography>
                <List sx={{ mt: 3, mb: 3 }}>
                  {items.map((item, index) => (
                    <ListItem
                      key={index}
                      sx={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'flex-start',
                        '&:hover': {
                          cursor: 'pointer' // Change mouse cursor to pointer on hover
                        }
                      }}
                    >
                      <Box sx={{ display: 'flex', alignItems: 'center', p: 1, ml: -5 }}>
                        <ListItemAvatar>
                          <Avatar aria-label='recipe'>{pageData.pagename.charAt(0).toUpperCase()}</Avatar>
                        </ListItemAvatar>
                        <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                          <Typography variant='body1'>{item.title}</Typography>
                          <Typography variant='body2'>{item.type}</Typography>
                        </Box>
                      </Box>
                      <Typography variant='body2' sx={{ alignSelf: 'center' }}>
                        {item.date}
                      </Typography>
                    </ListItem>
                  ))}
                </List>
                <Typography variant='body2' sx={{ alignSelf: 'center' }}>
                  Load More ...
                </Typography>
              </CardContent>
            </Card>
          </Box>
        </Grid>
        <Grid item xs={12} md={6}>
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'center',
              flex: 1,
              backgroundColor: 'background.paper',
              boxShadow: 2,
              borderRadius: 2
            }}
          >
            <Box
              sx={{
                justifyContent: 'center',
                flex: '1',
                mt: 7,
                mb: 5,
                pl: 8,
                pr: 8
              }}
            >
              <form noValidate autoComplete='off' onSubmit={handleSubmit}>
                <Typography variant='h4' sx={{ textAlign: 'center' }}>
                  Send A Note To {pageData.pagename}
                </Typography>
                <Box
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 5,
                    p: 5,
                    mt: 7,
                    mb: 7,
                    backgroundColor: colorGroup.background,
                    borderRadius: 1,
                    boxShadow: 1
                  }}
                >
                  <Box
                    component='img'
                    src='/images/logos/stellar.png'
                    alt='Icon'
                    sx={{ width: 60, height: 60, ml: 3 }}
                  />

                  <Typography variant='h5' sx={{ textAlign: 'center', ml: 2, mr: 2 }}>
                    x
                  </Typography>

                  <Avatar
                    onClick={() => handleAvatarClick(10)}
                    sx={{
                      bgcolor: selectedAvatar === 10 ? colorGroup.selected : colorGroup.unselected,
                      color: 'white',
                      width: 50,
                      height: 50,
                      cursor: 'pointer'
                    }}
                  >
                    10
                  </Avatar>
                  <Avatar
                    onClick={() => handleAvatarClick(30)}
                    sx={{
                      bgcolor: selectedAvatar === 30 ? colorGroup.selected : colorGroup.unselected,
                      color: 'white',
                      width: 50,
                      height: 50,
                      cursor: 'pointer'
                    }}
                  >
                    30
                  </Avatar>
                  <Avatar
                    onClick={() => handleAvatarClick(50)}
                    sx={{
                      bgcolor: selectedAvatar === 50 ? colorGroup.selected : colorGroup.unselected,
                      color: 'white',
                      width: 50,
                      height: 50,
                      cursor: 'pointer'
                    }}
                  >
                    50
                  </Avatar>

                  <TextField
                    variant='outlined'
                    size='medium'
                    placeholder='10'
                    sx={{ width: '70px', ml: 4 }}
                    value={formValues.count || ''}
                    onChange={handleInputChange}
                    name='count'
                    error={!!formErrors.count}
                  />
                </Box>
                {formErrors.count && (
                  <Typography color='error' sx={{ mt: -4, ml: 1, fontSize: 14 }}>
                    {formErrors.count}
                  </Typography>
                )}
                <TextField
                  fullWidth
                  id='name'
                  name='name'
                  label='Name (optional)'
                  sx={{ mt: 4, mb: 2, background: colorGroup.background }}
                  value={formValues.name}
                  onChange={handleInputChange}
                  error={!!formErrors.name}
                  helperText={formErrors.name}
                />
                <TextField
                  id='description'
                  label='Note'
                  multiline
                  name='note'
                  rows={4}
                  fullWidth
                  sx={{ marginBottom: 2, mt: 2, background: colorGroup.background }}
                  value={formValues.note}
                  onChange={handleInputChange}
                  error={!!formErrors.note}
                />
                {formErrors.note && (
                  <Typography color='error' sx={{ mt: 0, ml: 1, fontSize: 14 }}>
                    {formErrors.note}
                  </Typography>
                )}
                <Box
                  sx={{
                    mb: 2,
                    display: 'flex',
                    alignItems: 'center',
                    flexWrap: 'wrap',
                    justifyContent: 'space-between'
                  }}
                >
                  <FormControlLabel
                    control={<Checkbox checked={formValues.is_private} onChange={handleCheckboxChange} />}
                    label='Private Note'
                  />
                </Box>
                <Button type='submit' fullWidth size='large' variant='contained' sx={{ marginBottom: 7, mt: 5 }}>
                  Send
                </Button>
              </form>
            </Box>
          </Box>
        </Grid>
      </Grid>
    </Box>
  )
}

export const getServerSideProps: GetServerSideProps = async context => {
  const { pagename } = context.params as { pagename: string }

  const response = await fetch(`${API_URL}/pageinfo/getinfo?page=${pagename}`)
  const userData = await response.json()

  const pageData = {
    pagename,
    userData: userData.result[0]
  }

  return {
    props: {
      pageData
    }
  }
}

export default UserPage
