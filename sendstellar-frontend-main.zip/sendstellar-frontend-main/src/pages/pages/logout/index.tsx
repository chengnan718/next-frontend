import { useUser } from 'src/utils/context/User/UserProvider'
import { useRouter } from 'next/router'
import { useEffect } from 'react'

const LogoutPage = () => {
  const router = useRouter()
  const { setUser, setJwtToken } = useUser()

  useEffect(() => {
    setUser(null)
    setJwtToken(null)
    router.push('/pages/login')
  }, [router, setJwtToken, setUser])

  return <></>
}

export default LogoutPage
