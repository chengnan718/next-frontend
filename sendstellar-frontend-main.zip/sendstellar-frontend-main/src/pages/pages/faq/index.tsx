// ** MUI Components
import CardContent from '@mui/material/CardContent'
import * as React from 'react'
import { Plus } from 'mdi-material-ui'
import { ReactNode } from 'react'
import Box from '@mui/material/Box'
import Typography from '@mui/material/Typography'
import Accordion from '@mui/material/Accordion'
import AccordionDetails from '@mui/material/AccordionDetails'
import AccordionSummary from '@mui/material/AccordionSummary'
import { styled } from '@mui/material/styles'
import MuiCard, { CardProps } from '@mui/material/Card'

// ** Navigation Imports
import UserLayout from 'src/layouts/UserLayout'

// ** Styled Components
const Card = styled(MuiCard)<CardProps>(({ theme }) => ({
  width: '100%',
  [theme.breakpoints.up('sm')]: { width: '80%' },
  [theme.breakpoints.up('md')]: { width: '56rem' }
}))

// Define FAQ items
const faqItems = [
  {
    id: 'panel1',
    title: 'What is <strong>SendMeANote.app</strong>?',
    content:
      '<strong>SendMeANote.app</strong> <a href="https://www.vocabulary.com/dictionary/incentivize" target="_blank">incentivizes</a> the sharing of knowledge.  What does this mean for you?  If you want to share your expertise, experience or influence, you can do so and be rewarded immediately with ASK tokens. Or if you want to reach out to someone who has  expertise, experience or influence, you can do so by sending them ASK tokens.'
  },
  {
    id: 'panel2',
    title: 'Can Experts ask other Experts questions?',
    content: 'No, only Clients can ask Experts questions or send comments.'
  },
  {
    id: 'panel3',
    title: 'If I want to be a Client and an Expert, do I need to have 2 separate accounts?',
    content:
      'Yes, you need to sign up as Client with one crypto wallet address, and as an Expert with a different crypto wallet address.'
  },
  {
    id: 'panel4',
    title: 'If my question or comment has not been responded to, can I retrieve my Ask tokens after 24 hours?',
    content:
      'Yes, after 24 hours, you simply click the "reclaim" button associated with your question, and your Ask tokens will be returned to your crypto wallet. Please note, Binance charges a small BNB fee for every transaction'
  }
]

const FAQPage = () => {
  const [expanded, setExpanded] = React.useState<string | false>(false)

  const handleChange = (panel: string) => (event: React.SyntheticEvent, isExpanded: boolean) => {
    setExpanded(isExpanded ? panel : false)
  }

  // ** Hooks

  return (
    <Box className='content-center'>
      <Card sx={{ zIndex: 1, margin: '0 auto', borderRadius: '30px' }}>
        <CardContent
          sx={{
            padding: theme => `${theme.spacing(6, 4, 3)} !important`,
            border: '1px solid',
            borderRadius: '90px',
            margin: { xs: '20px', sm: '50px' }
          }}
        >
          <Box sx={{ marginBottom: 5 }}>
            <Typography
              variant='h4'
              sx={{
                marginBottom: 7,
                marginTop: '15px',
                marginLeft: 0,
                cursor: 'pointer',
                fontFamily: 'cursive',
                textAlign: 'center'
              }}
            >
              Frequently Asked Questions
            </Typography>
          </Box>
          <Box sx={{ marginBottom: '30px' }}>
            {faqItems.map(item => (
              <Accordion
                key={item.id}
                expanded={expanded === item.id}
                onChange={handleChange(item.id)}
                style={{ borderRadius: '0', boxShadow: 'none' }}
              >
                <AccordionSummary expandIcon={<Plus />} aria-controls={`${item.id}-content`} id={`${item.id}-header`}>
                  <Typography sx={{ width: '100%', flexShrink: 0, fontSize: '16px', fontWeight: 'bold' }}>
                    <span dangerouslySetInnerHTML={{ __html: item.title }} />
                  </Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography>
                    <span dangerouslySetInnerHTML={{ __html: item.content }} />
                  </Typography>
                </AccordionDetails>
              </Accordion>
            ))}
          </Box>
        </CardContent>
      </Card>
    </Box>
  )
}

FAQPage.getLayout = (page: ReactNode) => <UserLayout>{page}</UserLayout>
export default FAQPage
