// ** React Imports
import { ChangeEvent, ReactNode, useState } from 'react'
import * as React from 'react'

// ** Next Imports
import Link from 'next/link'
import { useRouter } from 'next/router'

// ** MUI Components
import Box from '@mui/material/Box'
import Button from '@mui/material/Button'
import TextField from '@mui/material/TextField'
import Typography from '@mui/material/Typography'
import CardContent from '@mui/material/CardContent'
import { styled } from '@mui/material/styles'
import MuiCard, { CardProps } from '@mui/material/Card'
import { Stack, useTheme } from '@mui/material'
import { InformationOutline as InformationOutlineIcon, EmailAlertOutline as EmailIcon } from 'mdi-material-ui'
import { Controller, useForm } from 'react-hook-form'
import { CustomFormControl } from 'src/views/custom/CustomCard'
import UserLayout from 'src/layouts/UserLayout'

import Stepper from '@mui/material/Stepper'
import Step from '@mui/material/Step'
import StepLabel from '@mui/material/StepLabel'
import InputAdornment from '@mui/material/InputAdornment'
import Divider from '@mui/material/Divider'

import Twitter from 'mdi-material-ui/Twitter'
import Facebook from 'mdi-material-ui/Facebook'

import { useAppDispatch } from 'src/store/hooks'
import { showSnackBar } from 'src/store/slices/snackbar.slice'
import { showBackdrop, hideBackdrop } from 'src/store/slices/backdrop.slice'

const API_URL = process.env.NEXT_PUBLIC_API_URL

interface State {
  pagename: string
  email: string
  password: string
  showPassword: boolean
  fullname: string
  country: string
  phone: string
  website: string
  linkedin: string
  twitter: string
  facebook: string
}

interface PageState {
  keycode: string
}

// ** Styled Components
const Card = styled(MuiCard)<CardProps>(({ theme }) => ({
  width: '100%',
  [theme.breakpoints.up('sm')]: { width: '80%' },
  [theme.breakpoints.up('md')]: { width: '56rem' }
}))

const steps = ['Input a Page Name', 'Input a Credintial', 'Input some infomations']

const GradientGoogleIcon = () => (
  <svg width='20' height='20' viewBox='0 0 23 24' fill='none' xmlns='http://www.w3.org/2000/svg'>
    <path
      d='M22.7074 12.2531C22.7074 11.4389 22.6436 10.6203 22.5074 9.81934H11.582V14.4315H17.8385C17.5788 15.9191 16.7446 17.235 15.5232 18.0711V21.0638H19.2557C21.4476 18.9777 22.7074 15.8971 22.7074 12.2531Z'
      fill='#4285F4'
    ></path>
    <path
      d='M11.5851 23.9555C14.7091 23.9555 17.3436 22.8949 19.2631 21.0641L15.5305 18.0715C14.492 18.802 13.1514 19.2157 11.5894 19.2157C8.56757 19.2157 6.00542 17.1077 5.08611 14.2734H1.23438V17.3585C3.20068 21.403 7.20563 23.9555 11.5851 23.9555Z'
      fill='#34A853'
    ></path>
    <path
      d='M5.07965 14.2764C4.59446 12.7888 4.59446 11.1781 5.07965 9.69055V6.60547H1.23214C-0.410713 9.98981 -0.410713 13.9771 1.23214 17.3614L5.07965 14.2764Z'
      fill='#FBBC04'
    ></path>
    <path
      d='M11.5851 4.74065C13.2365 4.71424 14.8325 5.35678 16.0285 6.53624L19.3354 3.11669C17.2415 1.08344 14.4622 -0.0344006 11.5851 0.000807131C7.20564 0.000807131 3.20068 2.55337 1.23438 6.60225L5.08186 9.68733C5.99692 6.84871 8.56333 4.74065 11.5851 4.74065Z'
      fill='#EA4335'
    ></path>
  </svg>
)

const RegisterPage = () => {
  const dispatch = useAppDispatch()
  const router = useRouter()

  const [values, setValues] = useState<State>({
    pagename: '',
    email: '',
    password: '',
    showPassword: false,
    fullname: '',
    country: '',
    phone: '',
    website: '',
    linkedin: '',
    twitter: '',
    facebook: ''
  })
  const [errors, setErrors] = useState<State>({
    pagename: '',
    email: '',
    password: '',
    showPassword: false,
    fullname: '',
    country: '',
    phone: '',
    website: '',
    linkedin: '',
    twitter: '',
    facebook: ''
  })
  const [successMessage, setSuccessMessage] = useState<string>('')
  const [showEmailVerify, setShowEmailVerify] = useState(false)
  const [isRegistered, setIsRegistered] = useState(false)

  // react-hook-form
  const { control, handleSubmit, setError } = useForm<PageState>({
    defaultValues: {
      keycode: ''
    }
  })

  // theme
  const theme = useTheme()

  const [activeStep, setActiveStep] = React.useState(0)

  const handleNext = () => {
    setActiveStep(prevActiveStep => prevActiveStep + 1)
  }

  const handleBack = () => {
    setActiveStep(prevActiveStep => prevActiveStep - 1)
  }

  const handleChange = (prop: keyof State) => (event: ChangeEvent<HTMLInputElement>) => {
    const value = event.target.value
    setValues({ ...values, [prop]: value })
  }

  const email_verification = () => {
    const options = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(values)
    }
    console.log('Sent', values)

    fetch(`${API_URL}/email/send-verification-email`, options)
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          console.log('Sent verification code')
        } else {
          throw new Error(data.msg)
        }
      })
      .catch(error => {
        console.log(error)
      })
  }

  const register_account = () => {
    if (isRegistered) return

    const options = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(values)
    }

    dispatch(
      showBackdrop({
        message: `Please wait for register...`
      })
    )

    fetch(`${API_URL}/auth/register`, options)
      .then(response => response.json())
      .then(data => {
        dispatch(hideBackdrop(null))

        if (data.success) {
          dispatch(hideBackdrop(null))
          dispatch(showSnackBar({ type: 'success', message: `${data.msg}` }))
          setShowEmailVerify(true)
          setIsRegistered(true)
          email_verification()
        } else {
          throw new Error(data.msg)
        }
      })
      .catch(error => {
        console.log(error)
        dispatch(hideBackdrop(null))
        dispatch(showSnackBar({ type: 'error', message: `${error.message || error.toString()}` }))
      })
  }

  const onSubmit = async (data: any) => {
    try {
      dispatch(hideBackdrop(null))

      const response = await fetch(`${API_URL}/email/verify-email-code`, {
        method: 'POST',
        body: JSON.stringify({
          code: `${data.keycode}`,
          email: values.email
        })
      })

      const { success, msg } = await response.json()
      console.log('code', `${data.keycode}`)

      if (!success) {
        throw new Error(msg || 'Error on email verification. Please resend new verification email.')
      }
      dispatch(hideBackdrop(null))
      router.push('/pages/login')
    } catch (e: any) {
      dispatch(hideBackdrop(null))
      setError('keycode', { type: 'manual', message: e.message || e.toString() })
    }
  }

  function getStepContent(step: any) {
    switch (step) {
      case 0:
        return (
          <Box>
            <Typography variant='h6'>Enter your name for the published page</Typography>
            <TextField
              autoFocus
              id='pagename'
              label='Page Name'
              size='medium'
              sx={{
                marginBottom: 4,
                marginTop: 8,
                width: '500px'
              }}
              InputProps={{
                startAdornment: <InputAdornment position='start'>sendmeanote.app/c/</InputAdornment>
              }}
              onChange={handleChange('pagename')}
              value={values.pagename}
              error={!!errors.pagename}
              helperText={errors.pagename}
            />
            <Typography variant='body2' sx={{ marginTop: 2 }}>
              {`Your URL: https://sendmeanote.app/c/${values.pagename || ''}`}
            </Typography>
          </Box>
        )
      case 1:
        // Validate the blank name input
        if (values.pagename === '') {
          setActiveStep(0)
          setErrors({ ...errors, pagename: 'Input the page name' })
        }

        return (
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              margin: '0 auto'
            }}
          >
            <Typography variant='h6'>Enter your credentials</Typography>
            <TextField
              autoFocus
              id='email'
              label='Email'
              size='medium'
              sx={{ marginBottom: 4, marginTop: 8, width: '500px' }}
              value={values.email}
              onChange={handleChange('email')}
              error={!!errors.email}
              helperText={errors.email}
            />

            <TextField
              id='password'
              label='Password'
              type='password'
              size='medium'
              sx={{ marginBottom: 4, width: '500px' }}
              value={values.password}
              onChange={handleChange('password')}
              error={!!errors.password}
              helperText={errors.password}
            />

            <Box sx={{ width: '500px', textAlign: 'center', mt: 4 }}>
              <Divider sx={{ width: '100%' }}>or</Divider>
            </Box>
            <Box mt={4} sx={{ width: '500px' }}>
              <Button fullWidth size='large' variant='outlined' sx={{ marginBottom: 3 }}>
                <GradientGoogleIcon />
                <Box component='span' sx={{ marginLeft: 3 }}>
                  Continue with Google
                </Box>
              </Button>
              <Button fullWidth size='large' variant='outlined' sx={{ marginBottom: 3 }}>
                <Facebook sx={{ color: '#497ce2', marginLeft: 4 }} />
                <Box component='span' sx={{ marginLeft: 3 }}>
                  Continue with Facebook
                </Box>
              </Button>
              <Button fullWidth size='large' variant='outlined' sx={{ marginBottom: 3 }}>
                <Twitter sx={{ color: '#1da1f2' }} />
                <Box component='span' sx={{ marginLeft: 3 }}>
                  Continue with Twitter
                </Box>
              </Button>
            </Box>
          </Box>
        )
      case 2:
        if (values.email === '' || values.password === '') {
          setActiveStep(1)
        }

        return (
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              margin: '0 auto'
            }}
          >
            <Typography variant='h6'>Input your infomations</Typography>
            <TextField
              autoFocus
              id='fullname'
              label='FullName'
              size='medium'
              sx={{ marginBottom: 4, marginTop: 8, width: '500px' }}
              value={values.fullname}
              onChange={handleChange('fullname')}
              error={!!errors.fullname}
              helperText={errors.fullname}
            />

            <TextField
              id='country'
              label='Country'
              size='medium'
              sx={{ marginBottom: 4, width: '500px' }}
              value={values.country}
              onChange={handleChange('country')}
              error={!!errors.country}
              helperText={errors.country}
            />

            <TextField
              id='phone'
              label='Phone'
              size='medium'
              sx={{ marginBottom: 4, width: '500px' }}
              value={values.phone}
              onChange={handleChange('phone')}
              error={!!errors.phone}
              helperText={errors.phone}
            />

            <TextField
              id='website'
              label='Website'
              size='medium'
              sx={{ marginBottom: 4, width: '500px' }}
              value={values.website}
              onChange={handleChange('website')}
              error={!!errors.website}
              helperText={errors.website}
            />
          </Box>
        )
      default:
        return 'Unkown Error'
    }
  }

  return (
    <Box sx={{ margin: '0 auto' }}>
      <Card sx={{ zIndex: 1, margin: '0 auto', borderRadius: '30px' }}>
        <CardContent
          sx={{ padding: theme => `${theme.spacing(12, 9, 7)} !important`, margin: { xs: '10px', sm: '10px' } }}
        >
          <Box sx={{ mb: 10 }}>
            <Typography variant='h5' sx={{ fontWeight: 600, marginBottom: 5, textAlign: 'center' }}>
              {'Welcome to Sendmeanote.app'}
            </Typography>
          </Box>

          <Box sx={{ width: '100%', mt: 15 }}>
            <Stepper activeStep={activeStep}>
              {steps.map(label => {
                const stepProps: { completed?: boolean } = {}
                const labelProps: {
                  optional?: React.ReactNode
                } = {}

                return (
                  <Step key={label} {...stepProps}>
                    <StepLabel {...labelProps}>{label}</StepLabel>
                  </Step>
                )
              })}
            </Stepper>
            {activeStep === steps.length ? (
              <React.Fragment>
                <Typography sx={{ mt: 10, mb: 1, textAlign: 'center' }}>{register_account()}</Typography>
                <Box sx={{ display: 'flex', flexDirection: 'row', pt: 2 }}>
                  {showEmailVerify && (
                    <form onSubmit={handleSubmit(onSubmit)} style={{ width: '100%' }}>
                      <Card sx={{ width: '100%', maxWidth: '800px', margin: 'auto' }}>
                        <CardContent>
                          <Stack alignItems={'center'} spacing={6}>
                            <Box>
                              <EmailIcon style={{ fontSize: '6rem', color: theme.palette.primary.main }} />
                            </Box>
                            <Box textAlign={'center'}>
                              <Typography variant='h5'>
                                We sent verification a email to{' '}
                                <Typography component={'span'} variant='h5' color={'primary.main'}>
                                  {values.email}
                                </Typography>
                                .
                              </Typography>
                              <Typography variant='h5'>Please input the 6 digit code from your email.</Typography>
                            </Box>
                            <Box>
                              <Stack direction={'row'} alignItems={'center'} spacing={1}>
                                <InformationOutlineIcon className='extra-small-icon' color='info' fontSize='small' />
                                <Typography variant='caption' color='info'>
                                  Verification email expires after 5 minutes.
                                </Typography>
                              </Stack>
                            </Box>
                            <Box textAlign={'center'}>
                              <Typography variant='body2'>
                                Didn't receive our reset password email ?{' '}
                                <Link
                                  href='#'
                                  onClick={() => {
                                    if (
                                      confirm(`Are you sure you want to send another verification code to your email?`)
                                    ) {
                                      setShowEmailVerify(true)
                                    }
                                  }}
                                >
                                  Resend
                                </Link>
                              </Typography>
                              <Typography variant='body2'>
                                Or please check your spam folder if you cannot find it in your inbox.
                              </Typography>
                            </Box>
                            <Box>
                              <Controller
                                name='keycode'
                                control={control}
                                rules={{
                                  required: 'Please fill code', // Ensures the field is not empty
                                  pattern: {
                                    value: /^\d{6}$/, // Regex for exactly 6 digits
                                    message: 'Invalid code' // Message to show when the pattern validation fails
                                  }
                                }}
                                render={({ field, fieldState: { error } }) => (
                                  <CustomFormControl fullWidth>
                                    <TextField
                                      {...field}
                                      error={!!error}
                                      className={'control-element'}
                                      placeholder='123456'
                                    />
                                    {error && (
                                      <Typography variant={'caption'} color={'error'}>
                                        {error.message}
                                      </Typography>
                                    )}
                                    {successMessage && (
                                      <Typography variant={'caption'} color={theme.palette.success.main}>
                                        {successMessage}
                                      </Typography>
                                    )}
                                  </CustomFormControl>
                                )}
                              />

                              {/** BEGIN confirm_button */}
                              <Box>
                                <Button type='submit' variant='contained' fullWidth color='success'>
                                  Confirm
                                </Button>
                              </Box>
                              {/** END confirm_button */}
                            </Box>
                          </Stack>
                        </CardContent>
                      </Card>
                    </form>
                  )}
                </Box>
              </React.Fragment>
            ) : (
              <React.Fragment>
                <Typography sx={{ mt: 10, mb: 1, textAlign: 'center' }}>{getStepContent(activeStep)}</Typography>
                <Box sx={{ display: 'flex', flexDirection: 'row', pt: 2 }}>
                  <Button color='inherit' disabled={activeStep === 0} onClick={handleBack} sx={{ mr: 1 }}>
                    Back
                  </Button>
                  <Box sx={{ flex: '1 1 auto' }} />
                  <Button onClick={handleNext}>{activeStep === steps.length - 1 ? 'Register' : 'Next'}</Button>
                </Box>
              </React.Fragment>
            )}
          </Box>
        </CardContent>
      </Card>
    </Box>
  )
}

RegisterPage.getLayout = (page: ReactNode) => <UserLayout>{page}</UserLayout>

export default RegisterPage
