// ** MUI Imports
import { Box, Button, Card, CardContent, Stack, TextField, Typography, useTheme } from '@mui/material'
import {
  InformationOutline as InformationOutlineIcon,
  EmailLockOutline as EmailLockIcon,
  ArrowLeft as ArrowLeftIcon
} from 'mdi-material-ui'

import { Controller, useForm } from 'react-hook-form'
import { CustomFormControl } from 'src/views/custom/CustomCard'
import { ReactNode, useState } from 'react'
import { showBackdrop, hideBackdrop } from 'src/store/slices/backdrop.slice'
import { useAppDispatch } from 'src/store/hooks'
import { useRouter } from 'next/router'
import BlankLayout from 'src/@core/layouts/BlankLayout'

const API_URL = process.env.NEXT_PUBLIC_API_URL

interface PageState {
  email: string
}

const ResetPasswordRequest = () => {
  const dispatch = useAppDispatch()
  const router = useRouter()

  // theme
  const theme = useTheme()

  // ** States
  const [successMessage, setSuccessMessage] = useState<string>('')

  // react-hook-form
  const {
    control,
    handleSubmit,
    setError,
    formState: {}
  } = useForm<PageState>({
    defaultValues: {
      email: ''
    }
  })

  const onSubmit = async (data: any) => {
    try {
      setSuccessMessage('')
      dispatch(showBackdrop({ message: `Please wait...` }))

      const response = await fetch(`${API_URL}/auth/request_password_reset`, {
        method: 'POST',
        body: JSON.stringify({
          email: `${data.email}`
        })
      })
      const { success, msg } = await response.json()

      if (!success) {
        throw new Error(msg || 'Error on requesting password reset.')
      }
      dispatch(hideBackdrop(null))
      alert(`Password reset email was sent. Please check your inbox.`)
    } catch (e: any) {
      dispatch(hideBackdrop(null))
      setError('email', { type: 'manual', message: e.message || e.toString() })
    }
  }

  return (
    <>
      <Box className='content-center'>
        <form onSubmit={handleSubmit(onSubmit)}>
          <Card>
            <CardContent>
              <Box>
                <Button
                  variant='outlined'
                  onClick={() => {
                    router.push('/pages/login')
                  }}
                >
                  <ArrowLeftIcon /> Back
                </Button>
              </Box>
              <Stack alignItems={'center'} spacing={6}>
                <Box>
                  <EmailLockIcon style={{ fontSize: '6rem', color: theme.palette.primary.main }} />
                </Box>
                <Box textAlign={'center'}>
                  <Typography variant='h5'>
                    Please input your account's email address to{' '}
                    <span style={{ color: theme.palette.error.main }}>reset</span> password.
                  </Typography>
                </Box>
                <Box>
                  <Stack direction={'row'} alignItems={'center'} spacing={1}>
                    <InformationOutlineIcon className='extra-small-icon' color='info' fontSize='small' />
                    <Typography variant='caption' color='info'>
                      Password reset email expires after 10 minutes.
                    </Typography>
                  </Stack>
                </Box>
                <Box>
                  <Controller
                    name='email'
                    control={control}
                    rules={{
                      required: 'Please fill email address', // Ensures the field is not empty
                      pattern: {
                        value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, // Regex for email validation
                        message: 'Invalid email address' // Message to show when the pattern validation fails
                      }
                    }}
                    render={({ field, fieldState: { error } }) => (
                      <CustomFormControl fullWidth style={{ marginBottom: 10 }}>
                        <TextField
                          {...field}
                          error={!!error}
                          className={'control-element'}
                          placeholder='youremail@example.com'
                        />
                        {error && (
                          <Typography variant={'caption'} color={'error'}>
                            {error.message}
                          </Typography>
                        )}
                        {successMessage && (
                          <Typography variant={'caption'} color={theme.palette.success.main}>
                            {successMessage}
                          </Typography>
                        )}
                      </CustomFormControl>
                    )}
                  />

                  {/** BEGIN confirm_button */}
                  <Box>
                    <Button type='submit' variant='contained' fullWidth color='success'>
                      Confirm
                    </Button>
                  </Box>
                  {/** END confirm_button */}
                </Box>

                <Box textAlign={'center'}>
                  <Typography variant='body2'>Didn't receive our reset password email ?</Typography>
                  <Typography variant='body2'>
                    Please check your spam folder if you cannot find it in your inbox.
                  </Typography>
                </Box>
              </Stack>
            </CardContent>
          </Card>
        </form>
      </Box>
    </>
  )
}

ResetPasswordRequest.getLayout = (page: ReactNode) => <BlankLayout>{page}</BlankLayout>

export default ResetPasswordRequest
