// ** React Imports
import { ChangeEvent, MouseEvent, ReactNode, useState } from 'react'

// ** Next Imports
import Link from 'next/link'
import { useRouter } from 'next/router'

// ** MUI Components
import { Button, Box } from '@mui/material'
import Divider from '@mui/material/Divider'
import Checkbox from '@mui/material/Checkbox'
import TextField from '@mui/material/TextField'
import InputLabel from '@mui/material/InputLabel'
import Typography from '@mui/material/Typography'
import IconButton from '@mui/material/IconButton'
import CardContent from '@mui/material/CardContent'
import FormControl from '@mui/material/FormControl'
import OutlinedInput from '@mui/material/OutlinedInput'
import { styled } from '@mui/material/styles'
import MuiCard, { CardProps } from '@mui/material/Card'
import InputAdornment from '@mui/material/InputAdornment'
import MuiFormControlLabel, { FormControlLabelProps } from '@mui/material/FormControlLabel'

// ** Icons Imports
import Twitter from 'mdi-material-ui/Twitter'
import Facebook from 'mdi-material-ui/Facebook'
import EyeOutline from 'mdi-material-ui/EyeOutline'
import EyeOffOutline from 'mdi-material-ui/EyeOffOutline'

// ** Demo Imports
import { Alert } from '@mui/material'
import { showBackdrop, hideBackdrop } from 'src/store/slices/backdrop.slice'
import { useAppDispatch } from 'src/store/hooks'
import { useUser } from 'src/utils/context/User/UserProvider'

// ** Navigation Imports
import UserLayout from 'src/layouts/UserLayout'

const API_URL = process.env.NEXT_PUBLIC_API_URL

interface State {
  email: string
  password: string
  showPassword: boolean
}

interface LoginResult {
  status: 'error' | 'success'
  message: string
}

// ** Styled Components
const Card = styled(MuiCard)<CardProps>(({ theme }) => ({
  width: '100%',
  [theme.breakpoints.up('sm')]: { width: '80%' },
  [theme.breakpoints.up('md')]: { width: '30rem' }
}))

const LinkStyled = styled('span')(({ theme }) => ({
  fontSize: '0.875rem',
  textDecoration: 'none',
  color: theme.palette.primary.main
}))

const FormControlLabel = styled(MuiFormControlLabel)<FormControlLabelProps>(({ theme }) => ({
  '& .MuiFormControlLabel-label': {
    fontSize: '0.875rem',
    color: theme.palette.text.secondary
  }
}))

const GradientGoogleIcon = () => (
  <svg width='20' height='20' viewBox='0 0 23 24' fill='none' xmlns='http://www.w3.org/2000/svg'>
    <path
      d='M22.7074 12.2531C22.7074 11.4389 22.6436 10.6203 22.5074 9.81934H11.582V14.4315H17.8385C17.5788 15.9191 16.7446 17.235 15.5232 18.0711V21.0638H19.2557C21.4476 18.9777 22.7074 15.8971 22.7074 12.2531Z'
      fill='#4285F4'
    ></path>
    <path
      d='M11.5851 23.9555C14.7091 23.9555 17.3436 22.8949 19.2631 21.0641L15.5305 18.0715C14.492 18.802 13.1514 19.2157 11.5894 19.2157C8.56757 19.2157 6.00542 17.1077 5.08611 14.2734H1.23438V17.3585C3.20068 21.403 7.20563 23.9555 11.5851 23.9555Z'
      fill='#34A853'
    ></path>
    <path
      d='M5.07965 14.2764C4.59446 12.7888 4.59446 11.1781 5.07965 9.69055V6.60547H1.23214C-0.410713 9.98981 -0.410713 13.9771 1.23214 17.3614L5.07965 14.2764Z'
      fill='#FBBC04'
    ></path>
    <path
      d='M11.5851 4.74065C13.2365 4.71424 14.8325 5.35678 16.0285 6.53624L19.3354 3.11669C17.2415 1.08344 14.4622 -0.0344006 11.5851 0.000807131C7.20564 0.000807131 3.20068 2.55337 1.23438 6.60225L5.08186 9.68733C5.99692 6.84871 8.56333 4.74065 11.5851 4.74065Z'
      fill='#EA4335'
    ></path>
  </svg>
)

const LoginPage = () => {
  const dispatch = useAppDispatch()

  const [values, setValues] = useState<State>({
    email: '',
    password: '',
    showPassword: false
  })

  const [loginResult, setLoginResult] = useState<LoginResult | null>(null)

  // ** Hook
  const router = useRouter()
  const { setUser, setJwtToken } = useUser()

  const handleChange = (prop: keyof State) => (event: ChangeEvent<HTMLInputElement>) => {
    setValues({ ...values, [prop]: event.target.value })
  }

  const handleClickShowPassword = () => {
    setValues({ ...values, showPassword: !values.showPassword })
  }

  const handleMouseDownPassword = (event: MouseEvent<HTMLButtonElement>) => {
    event.preventDefault()
  }

  const handleSubmit = (e: any) => {
    e.preventDefault()
    console.log(values)

    const options = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(values)
    }

    dispatch(
      showBackdrop({
        message: `Please wait...`
      })
    )

    fetch(API_URL + '/auth/login', options)
      .then(response => response.json())
      .then(data => {
        dispatch(hideBackdrop(null))

        if (data.success) {
          setLoginResult({ status: 'success', message: 'Succefully Logined.' })
          setUser(data?.user)
          setJwtToken(data?.jwt_token)
          router.push('/dashboard')
        } else {
          setLoginResult({ status: 'error', message: data.msg })
        }
      })
      .catch(error => {
        console.log(error)
        dispatch(hideBackdrop(null))
        setLoginResult({ status: 'error', message: `Error on AJAX call: ${error.toString()}` })
      })
  }

  return (
    <Box className='content-center' sx={{ margin: '0 auto' }}>
      <Card sx={{ zIndex: 1, margin: '0 auto', borderRadius: '30px' }}>
        <CardContent
          sx={{ padding: theme => `${theme.spacing(12, 9, 7)} !important`, margin: { xs: '10px', sm: '10px' } }}
        >
          <Box sx={{ mb: 6 }}>
            <Typography variant='h5' sx={{ fontWeight: 600, marginBottom: 5, textAlign: 'center' }}>
              {/* Welcome to Asked.app */}
              {'Welcome to Sendmeanote.app'}
            </Typography>
            {/* 🚀 */}
            <Typography variant='body1' sx={{ textAlign: 'center', marginBottom: 10 }}>
              Please sign-in to your account and start the adventure!
            </Typography>
          </Box>

          {loginResult && (
            <Alert severity={loginResult?.status} sx={{ mb: 1 }} style={{ marginBottom: '1em' }}>
              {loginResult?.message}
            </Alert>
          )}

          <form noValidate autoComplete='off' onSubmit={handleSubmit}>
            <TextField
              autoFocus
              fullWidth
              id='email'
              label='Email'
              sx={{ marginBottom: 4 }}
              value={values.email}
              onChange={handleChange('email')}
            />
            <FormControl fullWidth>
              <InputLabel htmlFor='auth-login-password'>Password</InputLabel>
              <OutlinedInput
                label='Password'
                value={values.password}
                id='auth-login-password'
                onChange={handleChange('password')}
                type={values.showPassword ? 'text' : 'password'}
                endAdornment={
                  <InputAdornment position='end'>
                    <IconButton
                      edge='end'
                      onClick={handleClickShowPassword}
                      onMouseDown={handleMouseDownPassword}
                      aria-label='toggle password visibility'
                    >
                      {values.showPassword ? <EyeOutline /> : <EyeOffOutline />}
                    </IconButton>
                  </InputAdornment>
                }
              />
            </FormControl>
            <Box
              sx={{
                mb: 4,
                mt: 4,
                display: 'flex',
                alignItems: 'center',
                flexWrap: 'wrap',
                justifyContent: 'space-between'
              }}
            >
              <FormControlLabel control={<Checkbox />} label='Remember Me' />
              <Link passHref href='/pages/reset-password-request'>
                <LinkStyled>Forgot Password?</LinkStyled>
              </Link>
            </Box>
            <Button type='submit' fullWidth size='large' variant='contained' sx={{ marginBottom: 7 }}>
              Login
            </Button>
            <Box sx={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', justifyContent: 'center' }}>
              <Typography variant='body2' sx={{ marginRight: 2 }}>
                New to our platform?
              </Typography>
              <Typography variant='body2'>
                <Link passHref href='/pages/register'>
                  <LinkStyled>Create an account</LinkStyled>
                </Link>
              </Typography>
            </Box>

            <Divider sx={{ my: 5 }}>or</Divider>
            <Box mt={4}>
              <Button fullWidth size='large' variant='outlined' sx={{ marginBottom: 3 }}>
                <GradientGoogleIcon />
                <Box component='span' sx={{ marginLeft: 3 }}>
                  Login with Google
                </Box>
              </Button>
              <Button fullWidth size='large' variant='outlined' sx={{ marginBottom: 3 }}>
                <Facebook sx={{ color: '#497ce2', marginLeft: 4 }} />
                <Box component='span' sx={{ marginLeft: 3 }}>
                  Login with Facebook
                </Box>
              </Button>
              <Button fullWidth size='large' variant='outlined' sx={{ marginBottom: 3 }}>
                <Twitter sx={{ color: '#1da1f2' }} />
                <Box component='span' sx={{ marginLeft: 3 }}>
                  Login with Twitter
                </Box>
              </Button>
            </Box>
          </form>
        </CardContent>
      </Card>
    </Box>
  )
}

LoginPage.getLayout = (page: ReactNode) => <UserLayout>{page}</UserLayout>

export default LoginPage
