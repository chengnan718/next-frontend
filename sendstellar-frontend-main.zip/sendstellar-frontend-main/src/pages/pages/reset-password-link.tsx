// ** MUI Imports
import { Box, Button, Card, CardContent, Stack, TextField, Typography, useTheme } from '@mui/material'
import { EmailLockOutline as EmailLockIcon, ArrowLeft as ArrowLeftIcon } from 'mdi-material-ui'

import { Controller, useForm } from 'react-hook-form'
import { CustomFormControl } from 'src/views/custom/CustomCard'
import { ReactNode, useState } from 'react'
import { showBackdrop, hideBackdrop } from 'src/store/slices/backdrop.slice'
import { useAppDispatch } from 'src/store/hooks'
import { useRouter } from 'next/router'
import BlankLayout from 'src/@core/layouts/BlankLayout'

const API_URL = process.env.NEXT_PUBLIC_API_URL

interface PageState {
  token: string
  newPassword: string
}

const ResetPasswordLink = () => {
  const dispatch = useAppDispatch()
  const router = useRouter()

  // theme
  const theme = useTheme()

  // URL params
  const params: any =
    typeof window !== 'undefined'
      ? new Proxy(new URLSearchParams(window.location.search), {
          get: (searchParams, prop) => searchParams.get(prop as string)
        })
      : null

  // ** States
  const [successMessage, setSuccessMessage] = useState<string>('')

  // react-hook-form
  const {
    control,
    handleSubmit,
    setError,
    formState: {}
  } = useForm<PageState>({
    defaultValues: {
      token: params?.token ?? '',
      newPassword: ''
    }
  })

  const onSubmit = async (data: any) => {
    try {
      setSuccessMessage('')
      dispatch(showBackdrop({ message: `Please wait...` }))

      const response = await fetch(`${API_URL}/auth/reset_password`, {
        method: 'POST',
        body: JSON.stringify({
          token: `${data.token}`,
          newPassword: `${data.newPassword}`
        })
      })
      const { success, msg } = await response.json()

      if (!success) {
        throw new Error(msg || 'Error during update password.')
      }
      dispatch(hideBackdrop(null))
      alert(`Password was updated successfully. Please try to login with it.`)
      router.push('/pages/login')
    } catch (e: any) {
      dispatch(hideBackdrop(null))
      setError('newPassword', { type: 'manual', message: e.message || e.toString() })
    }
  }

  return (
    <>
      <Box className='content-center'>
        <form onSubmit={handleSubmit(onSubmit)}>
          <Card>
            <CardContent>
              <Box>
                <Button
                  variant='outlined'
                  onClick={() => {
                    router.push('/pages/login')
                  }}
                >
                  <ArrowLeftIcon /> Back
                </Button>
              </Box>
              <Stack alignItems={'center'} spacing={6}>
                <Box>
                  <EmailLockIcon style={{ fontSize: '6rem', color: theme.palette.primary.main }} />
                </Box>
                <Box textAlign={'center'}>
                  <Typography variant='h5'>Please set your new password here.</Typography>
                </Box>
                <Box>
                  <Controller
                    name='newPassword'
                    control={control}
                    rules={{
                      required: 'Please fill password' // Ensures the field is not empty
                    }}
                    render={({ field, fieldState: { error } }) => (
                      <CustomFormControl fullWidth style={{ marginBottom: 10 }}>
                        <TextField {...field} error={!!error} className={'control-element'} type='password' />
                        {error && (
                          <Typography variant={'caption'} color={'error'}>
                            {error.message}
                          </Typography>
                        )}
                        {successMessage && (
                          <Typography variant={'caption'} color={theme.palette.success.main}>
                            {successMessage}
                          </Typography>
                        )}
                      </CustomFormControl>
                    )}
                  />

                  {/** BEGIN confirm_button */}
                  <Box>
                    <Button type='submit' variant='contained' fullWidth color='success'>
                      Confirm
                    </Button>
                  </Box>
                  {/** END confirm_button */}
                </Box>
              </Stack>
            </CardContent>
          </Card>
        </form>
      </Box>
    </>
  )
}

ResetPasswordLink.getLayout = (page: ReactNode) => <BlankLayout>{page}</BlankLayout>

export default ResetPasswordLink
