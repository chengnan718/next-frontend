declare global {
  type ID = string | number;
  type IdName = {
    id: ID,
    name: string;
  }

  interface Dict<Type> {
    [key: string]: Type;
  }

  type CountryType = {
    code: string;
    label: string;
    phone: string;
    suggested?: boolean;
  }

  type ExpertiseType = {  
    code: string;
    name: string;
    label: string;
  }

  type AvatarImage = {
    id: number,
    title: string;
    src: string;
  }
}

export {};