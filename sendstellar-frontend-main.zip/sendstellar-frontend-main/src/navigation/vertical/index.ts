// ** Icon imports
import Login from 'mdi-material-ui/Login'
import HomeOutline from 'mdi-material-ui/HomeOutline'
import ViewDashboard from 'mdi-material-ui/ViewDashboard'

import Magnify from 'mdi-material-ui/Magnify'
import AccountCogOutline from 'mdi-material-ui/AccountCogOutline'
import AccountPlusOutline from 'mdi-material-ui/AccountPlusOutline'
import QuestionMarkIcon from '@mui/icons-material/QuestionMark'
import TokenIcon from '@mui/icons-material/Token'

// ** Type import
import { VerticalNavItemsType } from 'src/@core/layouts/types'
import LogoutVariant from 'mdi-material-ui/LogoutVariant'

const navigation = (user: any): VerticalNavItemsType => {
  // Variable menu items
  const dashboard_menu = !user
    ? null
    : user?.role === 'client'
    ? {
        title: 'My Dashboard',
        icon: ViewDashboard,
        path: '/dashboard/client'
      }
    : {
        title: 'My Dashboard',
        icon: ViewDashboard,
        path: '/dashboard/expert'
      }

  const account_menus: any[] = !user
    ? [
        {
          sectionTitle: 'User'
        },
        {
          title: 'Login',
          icon: Login,
          path: '/pages/login',
          openInNewTab: true
        },
        {
          title: 'Register',
          icon: AccountPlusOutline,
          path: '/pages/register',
          openInNewTab: true
        }
      ]
    : [
        {
          sectionTitle: 'User'
        },
        {
          title: 'Profile Settings',
          icon: AccountCogOutline,
          path: '/account-settings'
        },
        {
          title: 'Log out',
          icon: LogoutVariant,
          path: '/pages/logout'
        }
      ]

  // This is main array
  const menus = [
    {
      title: 'Home',
      icon: HomeOutline,
      path: '/'
    },
    dashboard_menu,
    {
      title: 'FAQ',
      icon: QuestionMarkIcon,
      path: '/pages/faq'
    },
    {
      title: 'Search',
      icon: Magnify,
      path: '/experts'
    },
    {
      title: 'Buy Tokens',
      icon: TokenIcon,
      path: 'https://pancakeswap.finance/swap?outputCurrency=0x5892A89ca863E5c8eef4330eca77a9fF369896f5',
      openInNewTab: true
    },
    ...account_menus
  ]

  // Skip null items
  const final_menus: any[] = []
  for (let i = 0; i < menus.length; i++) {
    if (!menus[i]) {
      continue
    }
    final_menus.push(menus[i])
  }

  return final_menus
}

export default navigation
