# Run this script only on production server
git fetch --all
git reset --hard origin/main
npm install
npm run build
pm2 restart front
